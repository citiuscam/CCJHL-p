//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-G9wlJlIN.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/checkout",
			"/keranjang",
			"/tentang",
			"/toko",
			"/unduh",
			"/kategori/$slug",
			"/produk/$slug"
		],
		preloads: [
			"/assets/index-CE3oouna.js",
			"/assets/jsx-runtime-BkSabwWG.js",
			"/assets/button-C5rkABtR.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CE3oouna.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Ch-uXhKK.js", "/assets/product-grid-C14tCzoR.js"]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: ["/assets/checkout-Ddx9wJlx.js"]
	},
	"/keranjang": {
		filePath: "/workspace/src/routes/keranjang.tsx",
		children: void 0,
		preloads: ["/assets/keranjang-Dr_47qMy.js", "/assets/qty-stepper-CZs-KkeK.js"]
	},
	"/tentang": {
		filePath: "/workspace/src/routes/tentang.tsx",
		children: void 0,
		preloads: ["/assets/tentang-3yxdHNsn.js"]
	},
	"/toko": {
		filePath: "/workspace/src/routes/toko.tsx",
		children: void 0,
		preloads: ["/assets/toko-OKxKuCKz.js", "/assets/product-grid-C14tCzoR.js"]
	},
	"/unduh": {
		filePath: "/workspace/src/routes/unduh.tsx",
		children: void 0,
		preloads: ["/assets/unduh-DGleVStm.js"]
	},
	"/kategori/$slug": {
		filePath: "/workspace/src/routes/kategori.$slug.tsx",
		children: void 0,
		preloads: ["/assets/kategori._slug-CG0MoNq1.js", "/assets/product-grid-C14tCzoR.js"]
	},
	"/produk/$slug": {
		filePath: "/workspace/src/routes/produk.$slug.tsx",
		children: void 0,
		preloads: [
			"/assets/produk._slug-JqZPudRd.js",
			"/assets/produk._slug-djWqFlP-.js",
			"/assets/qty-stepper-CZs-KkeK.js",
			"/assets/product-grid-C14tCzoR.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
