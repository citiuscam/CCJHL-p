import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as stripHtml, S as sanitizeHtml, _ as discountPercent, b as primaryCategory, g as decodeHtml, l as useCart, n as Route, u as Button, y as formatWcPrice } from "./router-BkBHam3u.mjs";
import { n as ProductGrid, t as Badge } from "./product-grid-CLZ7GzUg.mjs";
import { t as QtyStepper } from "./qty-stepper-1gsE-ziI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/produk._slug-DtULIZ1w.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProductPage() {
	const { product, related } = Route.useLoaderData();
	const add = useCart((s) => s.add);
	const [qty, setQty] = (0, import_react.useState)(1);
	const [active, setActive] = (0, import_react.useState)(0);
	const priced = formatWcPrice(product.prices);
	const off = discountPercent(product.prices);
	const images = product.images.length ? product.images : [];
	const current = images[active] ?? images[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-[11px] uppercase tracking-[0.16em] text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/toko",
						search: { page: 1 },
						className: "hover:text-foreground",
						children: "Toko"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "mx-2",
						children: "/"
					}),
					primaryCategory(product)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-10 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "overflow-hidden rounded-xl bg-surface",
					children: current ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: current.src,
						alt: decodeHtml(current.alt || product.name),
						className: "aspect-square w-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "aspect-square bg-muted" })
				}), images.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-5 gap-2",
					children: images.slice(0, 5).map((img, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setActive(i),
						className: `overflow-hidden rounded-md border ${i === active ? "border-accent" : "border-transparent"}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: img.thumbnail || img.src,
							alt: "",
							className: "aspect-square object-cover"
						})
					}, `${img.id}-${i}`))
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [off ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
							variant: "sale",
							children: [
								"-",
								off,
								"%"
							]
						}) : null, product.is_in_stock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "Tersedia"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "outline",
							children: "Habis"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-4 font-display text-3xl leading-tight sm:text-4xl",
						children: decodeHtml(product.name)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 flex items-baseline gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-2xl font-medium tabular-nums",
							children: priced.label
						}), priced.onSale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm tabular-nums text-muted-foreground line-through",
							children: priced.regularLabel
						}) : null]
					}),
					stripHtml(product.short_description) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm leading-relaxed text-muted-foreground",
						children: stripHtml(product.short_description)
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QtyStepper, {
							value: qty,
							onChange: setQty,
							max: product.add_to_cart?.maximum ?? 99
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "lg",
							disabled: !product.is_purchasable || !product.is_in_stock,
							onClick: () => add(product, qty),
							children: "Tambah ke keranjang"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						className: "mt-3",
						size: "lg",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: product.permalink || "https://citiuscam.com",
							target: "_blank",
							rel: "noreferrer",
							children: "Lihat di citiuscam.com"
						})
					}),
					product.attributes?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
						className: "mt-8 grid grid-cols-2 gap-3 text-sm",
						children: product.attributes.map((attr) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-border bg-surface px-3 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-[10px] uppercase tracking-[0.14em] text-muted-foreground",
								children: attr.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1",
								children: attr.terms.map((t) => t.name).join(", ")
							})]
						}, attr.id))
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 flex flex-wrap gap-2",
						children: product.categories.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/kategori/$slug",
							params: { slug: cat.slug },
							className: "rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground",
							children: decodeHtml(cat.name)
						}, cat.id))
					})
				] })]
			}),
			product.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-14 max-w-3xl",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Detail"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "prose-citius mt-4 space-y-3 text-sm leading-relaxed text-muted-foreground [&_li]:ml-5 [&_li]:list-disc [&_p]:text-pretty",
					dangerouslySetInnerHTML: { __html: sanitizeHtml(product.description) }
				})]
			}) : null,
			related.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-16",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mb-8 font-display text-3xl",
					children: "Produk terkait"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: related })]
			}) : null
		]
	});
}
//#endregion
export { ProductPage as component };
