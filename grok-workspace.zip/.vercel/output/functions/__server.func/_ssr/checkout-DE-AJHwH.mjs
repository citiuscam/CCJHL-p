import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as cartSubtotal, f as COUPON_CODE, h as TELEGRAM_URL, l as useCart, m as OFFICIAL_STORE, o as Input, u as Button, v as formatIdr } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-DE-AJHwH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CheckoutPage() {
	const items = useCart((s) => s.items);
	const clear = useCart((s) => s.clear);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [name, setName] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [city, setCity] = (0, import_react.useState)("Jakarta");
	const [note, setNote] = (0, import_react.useState)("");
	const [sent, setSent] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => setMounted(true), []);
	const message = (0, import_react.useMemo)(() => {
		const lines = items.map((item) => `- ${item.name} × ${item.qty} @ ${formatIdr(item.price)}`);
		return [
			`Pesanan CitiusCam`,
			`Nama: ${name || "-"}`,
			`WA: ${phone || "-"}`,
			`Kota: ${city || "-"}`,
			``,
			...lines,
			``,
			`Subtotal: ${formatIdr(cartSubtotal(items))}`,
			`Voucher: ${COUPON_CODE}`,
			note ? `Catatan: ${note}` : ""
		].filter(Boolean).join("\n");
	}, [
		items,
		name,
		phone,
		city,
		note
	]);
	if (!mounted) return null;
	if (!items.length && !sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl",
			children: "Keranjang kosong"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-8",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/toko",
				search: { page: 1 },
				children: "Belanja"
			})
		})]
	});
	if (sent) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl px-4 py-20 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Pesanan siap dikirim"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: "Lanjutkan di Telegram CitiusCam atau selesaikan di toko resmi."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: `${TELEGRAM_URL}?text=${encodeURIComponent(message)}`,
						target: "_blank",
						rel: "noreferrer",
						children: "Buka Telegram"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					variant: "outline",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: OFFICIAL_STORE,
						target: "_blank",
						rel: "noreferrer",
						children: "citiuscam.com"
					})
				})]
			})
		]
	});
	function onSubmit(event) {
		event.preventDefault();
		const url = `${TELEGRAM_URL}?text=${encodeURIComponent(message)}`;
		window.open(url, "_blank", "noopener,noreferrer");
		setSent(true);
		clear();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto grid max-w-5xl gap-10 px-4 py-10 lg:grid-cols-[1fr_0.85fr]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			onSubmit,
			className: "space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl",
					children: "Checkout"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted-foreground",
					children: [
						"Headless checkout mengirim ringkasan ke Telegram @citiuscam. Pembayaran dan pengiriman diselesaikan oleh toko resmi. Voucher ",
						COUPON_CODE,
						" berlaku di citiuscam.com."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Nama", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: name,
						onChange: (e) => setName(e.target.value),
						required: true,
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["WhatsApp / telepon", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: phone,
						onChange: (e) => setPhone(e.target.value),
						required: true,
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Kota", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: city,
						onChange: (e) => setCity(e.target.value),
						required: true,
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "block text-sm",
					children: ["Catatan", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: note,
						onChange: (e) => setNote(e.target.value),
						className: "mt-1.5"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "submit",
					size: "lg",
					className: "w-full sm:w-auto",
					children: "Kirim pesanan via Telegram"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "rounded-xl border border-border bg-surface p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Ringkasan"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3 text-sm",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "line-clamp-2 text-muted-foreground",
							children: [
								item.name,
								" × ",
								item.qty
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums",
							children: formatIdr(item.price * item.qty)
						})]
					}, item.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex justify-between border-t border-border pt-4 text-sm font-medium",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Subtotal" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: formatIdr(cartSubtotal(items))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-4 text-xs text-muted-foreground",
					children: [
						"Ongkir dihitung toko resmi. Cantumkan ",
						COUPON_CODE,
						" untuk 10% off."
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-xs",
					children: items.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: item.permalink,
						className: "text-accent underline-offset-2 hover:underline",
						target: "_blank",
						rel: "noreferrer",
						children: [
							"Buka ",
							item.name.slice(0, 40),
							" di toko resmi"
						]
					}) }, `off-${item.id}`))
				})
			]
		})]
	});
}
//#endregion
export { CheckoutPage as component };
