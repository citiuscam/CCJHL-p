import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as Button } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/produk._slug-BVFbw1lJ.js
var import_jsx_runtime = require_jsx_runtime();
var SplitNotFoundComponent = () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
	className: "mx-auto max-w-3xl px-4 py-20 text-center",
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
		className: "font-display text-4xl",
		children: "Produk tidak ditemukan"
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		asChild: true,
		className: "mt-6",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/toko",
			search: { page: 1 },
			children: "Kembali ke toko"
		})
	})]
});
//#endregion
export { SplitNotFoundComponent as notFoundComponent };
