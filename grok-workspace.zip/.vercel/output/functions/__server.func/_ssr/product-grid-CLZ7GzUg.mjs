import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as ShoppingBag } from "../_libs/lucide-react.mjs";
import { _ as discountPercent, b as primaryCategory, d as cn, g as decodeHtml, l as useCart, u as Button, x as productImage, y as formatWcPrice } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/product-grid-CLZ7GzUg.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-sm px-2 py-0.5 text-[10px] font-medium uppercase tracking-[0.14em]", {
	variants: { variant: {
		default: "bg-muted text-muted-foreground",
		sale: "bg-sale text-sale-foreground",
		outline: "border border-border text-muted-foreground",
		accent: "bg-accent text-accent-foreground"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function ProductCard({ product }) {
	const add = useCart((s) => s.add);
	const priced = formatWcPrice(product.prices);
	const off = discountPercent(product.prices);
	const image = productImage(product);
	const category = primaryCategory(product);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "group flex flex-col",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/produk/$slug",
			params: { slug: product.slug },
			className: "relative block overflow-hidden rounded-xl bg-surface",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "aspect-[4/5] overflow-hidden",
				children: image ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: image,
					alt: decodeHtml(product.images[0]?.alt || product.name),
					className: "size-full object-cover transition-transform duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)] group-hover:scale-[1.04]",
					loading: "lazy"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex size-full items-center justify-center bg-muted text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {
						className: "size-8",
						strokeWidth: 1.25
					})
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute left-3 top-3 flex flex-col gap-1.5",
				children: [off ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
					variant: "sale",
					children: [
						"-",
						off,
						"%"
					]
				}) : null, !product.is_in_stock ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					variant: "outline",
					children: "Habis"
				}) : null]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col gap-2 pt-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[10px] uppercase tracking-[0.16em] text-muted-foreground",
					children: category
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/produk/$slug",
					params: { slug: product.slug },
					className: "line-clamp-2 min-h-10 text-sm font-medium leading-snug text-foreground text-balance hover:text-accent",
					children: decodeHtml(product.name)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-auto flex items-end justify-between gap-3 pt-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium tabular-nums text-foreground",
							children: priced.label
						}), priced.onSale ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs tabular-nums text-muted-foreground line-through",
							children: priced.regularLabel
						}) : null]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "icon",
						variant: "secondary",
						className: "size-10 shrink-0 rounded-lg",
						disabled: !product.is_purchasable || !product.is_in_stock,
						"aria-label": `Tambah ${decodeHtml(product.name)} ke keranjang`,
						onClick: () => add(product),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, { strokeWidth: 1.75 })
					})]
				})
			]
		})]
	});
}
function ProductGrid({ products }) {
	if (!products.length) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "py-16 text-center text-sm text-muted-foreground",
		children: "Belum ada produk pada etalase ini."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4",
		children: products.map((product) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductCard, { product }, product.id))
	});
}
//#endregion
export { ProductGrid as n, Badge as t };
