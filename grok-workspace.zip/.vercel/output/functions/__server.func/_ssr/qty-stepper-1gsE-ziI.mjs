import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, o as Minus } from "../_libs/lucide-react.mjs";
import { d as cn } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qty-stepper-1gsE-ziI.js
var import_jsx_runtime = require_jsx_runtime();
function QtyStepper({ value, onChange, min = 1, max = 99, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: cn("inline-flex h-11 items-center rounded-md border border-border bg-surface", className),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-11 items-center justify-center text-muted-foreground hover:text-foreground",
				onClick: () => onChange(Math.max(min, value - 1)),
				"aria-label": "Kurangi jumlah",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, { className: "size-3.5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "w-8 text-center text-sm tabular-nums",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "flex size-11 items-center justify-center text-muted-foreground hover:text-foreground",
				onClick: () => onChange(Math.min(max, value + 1)),
				"aria-label": "Tambah jumlah",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" })
			})
		]
	});
}
//#endregion
export { QtyStepper as t };
