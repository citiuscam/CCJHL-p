import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, b as useNavigate, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { g as decodeHtml, i as Route$3, o as Input, u as Button } from "./router-BkBHam3u.mjs";
import { n as ProductGrid } from "./product-grid-CLZ7GzUg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/toko-hswMdLC9.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ShopPage() {
	const { listing, categories, page } = Route$3.useLoaderData();
	const search = Route$3.useSearch();
	const navigate = useNavigate({ from: "/toko" });
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	const [orderby, setOrderby] = (0, import_react.useState)(search.orderby ?? "date");
	const parentCats = categories.filter((c) => !c.parent && (c.count ?? 0) > 0);
	function onFilter(event) {
		event.preventDefault();
		navigate({ search: {
			q: q.trim() || void 0,
			orderby: orderby === "date" ? void 0 : orderby,
			page: 1,
			on_sale: search.on_sale
		} });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "Etalase"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl sm:text-5xl",
				children: "Semua produk"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-sm text-muted-foreground",
				children: [
					listing.total,
					" item dari WooCommerce Store API · halaman ",
					page,
					" / ",
					Math.max(1, listing.totalPages)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 flex flex-col gap-3 sm:flex-row",
				onSubmit: onFilter,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Cari sony, adapter, leica…",
						className: "sm:max-w-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
						value: orderby,
						onChange: (e) => setOrderby(e.target.value),
						className: "h-11 rounded-md border border-border bg-surface px-3 text-sm text-foreground",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "date",
								children: "Terbaru"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "popularity",
								children: "Terpopuler"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "price",
								children: "Harga"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: "title",
								children: "Nama"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						children: "Terapkan"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex gap-2 overflow-x-auto pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						to: "/toko",
						search: { page: 1 },
						active: !search.q && !search.on_sale,
						children: "Semua"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FilterChip, {
						to: "/toko",
						search: {
							on_sale: true,
							page: 1
						},
						active: !!search.on_sale,
						children: "Diskon"
					}),
					parentCats.slice(0, 10).map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/kategori/$slug",
						params: { slug: cat.slug },
						className: "shrink-0 rounded-full border border-border px-3 py-2 text-xs text-muted-foreground hover:text-foreground",
						children: decodeHtml(cat.name)
					}, cat.id))
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: listing.products })
			}),
			listing.totalPages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						className: page <= 1 ? "pointer-events-none opacity-40" : "",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toko",
							search: {
								...search,
								page: Math.max(1, page - 1)
							},
							children: "Sebelumnya"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm tabular-nums text-muted-foreground",
						children: [
							page,
							" / ",
							listing.totalPages
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						className: page >= listing.totalPages ? "pointer-events-none opacity-40" : "",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toko",
							search: {
								...search,
								page: page + 1
							},
							children: "Berikutnya"
						})
					})
				]
			}) : null
		]
	});
}
function FilterChip({ children, to, search, active }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to,
		search,
		className: `shrink-0 rounded-full border px-3 py-2 text-xs ${active ? "border-foreground bg-foreground text-bg" : "border-border text-muted-foreground hover:text-foreground"}`,
		children
	});
}
//#endregion
export { ShopPage as component };
