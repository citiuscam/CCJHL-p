import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { h as TELEGRAM_URL, m as OFFICIAL_STORE, p as INSTAGRAM_URL } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tentang-oa3KvStU.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "CitiusCam Jakarta"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-tight",
				children: "Shoot with Style"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-8 space-y-5 text-base leading-relaxed text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "CitiusCam adalah rumah aksesoris kamera dan gadget di Jakarta — adapter lensa lintas mount, hood, tutup body, remote, flash, sampai lensa manual antik dan barang collector." }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
						"Storefront ini headless: katalog, harga, dan stok ditarik live dari WooCommerce Store REST API ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
							className: "text-foreground",
							children: "/wp-json/wc/store/v1"
						}),
						" milik citiuscam.com. Tidak ada dummy catalog."
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Keranjang disimpan di perangkat Anda. Checkout mengirim ringkasan ke Telegram resmi, lalu pembayaran dan pengiriman diselesaikan di toko WordPress." })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-10 flex flex-wrap gap-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: OFFICIAL_STORE,
						className: "text-accent underline-offset-4 hover:underline",
						target: "_blank",
						rel: "noreferrer",
						children: "citiuscam.com"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: INSTAGRAM_URL,
						className: "text-accent underline-offset-4 hover:underline",
						target: "_blank",
						rel: "noreferrer",
						children: "Instagram"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: TELEGRAM_URL,
						className: "text-accent underline-offset-4 hover:underline",
						target: "_blank",
						rel: "noreferrer",
						children: "Telegram"
					})
				]
			})
		]
	});
}
//#endregion
export { AboutPage as component };
