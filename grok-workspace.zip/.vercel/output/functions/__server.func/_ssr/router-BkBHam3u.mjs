import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { S as require_jsx_runtime, Y as notFound, _ as createFileRoute, b as useNavigate, d as Scripts, f as HeadContent, g as lazyRouteComponent, h as Outlet, m as createRouter, v as createRootRoute, x as useRouter, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as boolean, o as string, r as literal, s as union, t as _enum } from "../_libs/zod.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as Search, n as TriangleAlert, r as ShoppingBag, s as Menu, t as X } from "../_libs/lucide-react.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/format-CNbUDF4T.js
var COUPON_CODE = "10-OFF26";
var STORE_NAME = "CitiusCam";
var TELEGRAM_URL = "https://t.me/citiuscam";
var INSTAGRAM_URL = "https://instagram.com/citiuscam";
var FACEBOOK_URL = "https://fb.me/citiuscam";
var X_URL = "https://twitter.com/citiuscam";
var OFFICIAL_STORE = "https://citiuscam.com";
var NAV_CATEGORIES = [
	{
		slug: "adapter-lensa",
		label: "Adapter"
	},
	{
		slug: "kamera",
		label: "Kamera"
	},
	{
		slug: "lensa",
		label: "Lensa"
	},
	{
		slug: "aksesoris",
		label: "Aksesoris"
	},
	{
		slug: "cuci-gudang",
		label: "Cuci Gudang"
	},
	{
		slug: "collectors-preloved",
		label: "Preloved"
	}
];
function decodeHtml(value) {
	return value.replace(/&#(\d+);/g, (_, code) => String.fromCharCode(Number(code))).replace(/&#x([0-9a-f]+);/gi, (_, hex) => String.fromCharCode(Number.parseInt(hex, 16))).replace(/&/g, "&").replace(/"/g, "\"").replace(/'/g, "'").replace(/</g, "<").replace(/>/g, ">").replace(/&nbsp;/g, " ");
}
function stripHtml(html) {
	if (!html) return "";
	return decodeHtml(html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}
function sanitizeHtml(html) {
	if (!html) return "";
	return html.replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "").replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "").replace(/\son\w+="[^"]*"/gi, "").replace(/\son\w+='[^']*'/gi, "").replace(/javascript:/gi, "");
}
function priceNumber(raw, minorUnit) {
	const n = Number(raw);
	if (!Number.isFinite(n)) return 0;
	return n / 10 ** minorUnit;
}
function formatIdr(amount) {
	return new Intl.NumberFormat("id-ID", {
		style: "currency",
		currency: "IDR",
		maximumFractionDigits: 0
	}).format(amount);
}
function formatWcPrice(prices) {
	const current = priceNumber(prices.price, prices.currency_minor_unit);
	const regular = priceNumber(prices.regular_price, prices.currency_minor_unit);
	return {
		current,
		regular,
		onSale: current > 0 && regular > current,
		label: formatIdr(current),
		regularLabel: formatIdr(regular)
	};
}
function discountPercent(prices) {
	const { current, regular, onSale } = formatWcPrice(prices);
	if (!onSale || regular <= 0) return null;
	return Math.round((regular - current) / regular * 100);
}
function productImage(product, size = "full") {
	const img = product.images[0];
	if (!img) return null;
	return size === "thumb" ? img.thumbnail || img.src : img.src;
}
function primaryCategory(product) {
	return decodeHtml((product.categories.find((c) => [
		"adapter-lensa",
		"kamera",
		"lensa",
		"aksesoris",
		"cuci-gudang",
		"collectors-preloved"
	].includes(c.slug)) ?? product.categories[0])?.name ?? "Gear");
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/button-DMvRLM74.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium transition-[opacity,transform,background-color,color,border-color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground border border-border hover:bg-muted",
			outline: "border border-border bg-transparent text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			accent: "bg-accent text-accent-foreground hover:opacity-90",
			link: "text-foreground underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-5",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-6",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/api-EY66Py26.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var listInput = object({
	page: number().int().min(1).optional(),
	perPage: number().int().min(1).max(48).optional(),
	category: union([number(), string()]).optional(),
	search: string().max(80).optional(),
	orderby: _enum([
		"date",
		"price",
		"popularity",
		"rating",
		"title",
		"menu_order"
	]).optional(),
	order: _enum(["asc", "desc"]).optional(),
	onSale: boolean().optional(),
	stockStatus: _enum([
		"instock",
		"outofstock",
		"onbackorder"
	]).optional()
});
var listProducts = createServerFn({ method: "GET" }).validator(listInput).handler(createSsrRpc("a64943a7b8be03c561a001c2a6107debcece9fe46e620c9f49159f79a0e6e2af"));
var getProductBySlug = createServerFn({ method: "GET" }).validator(object({ slug: string().min(1).max(200) })).handler(createSsrRpc("120a017d43b966bb20db2094d4a901af6437181809a1abcc08b41507429f7a40"));
createServerFn({ method: "GET" }).validator(object({ id: number().int().positive() })).handler(createSsrRpc("edcd3574333da2a171b9c6cb37ff3cfc01ecf699cd771903f5bf3079113d18c4"));
var listCategories = createServerFn({ method: "GET" }).handler(createSsrRpc("32fd37775d82fa29d30b03e087f017cd367a1d6f00ff4572338f70616c4005d2"));
var getCatalogHome = createServerFn({ method: "GET" }).handler(createSsrRpc("2ee734da33130981caf810eab72e67aa695d3fbcadbe4ceffb6ca043c07d6008"));
createServerFn({ method: "GET" }).validator(object({ q: string().min(1).max(80) })).handler(createSsrRpc("a7eb27003dbcafb3ba42b5b98cc0d874b8548ee50ea892aa326b9521070a3a80"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/shop-search-CVM67vCR.js
function parseShopSearch(search) {
	const orderbyRaw = search.orderby;
	const orderRaw = search.order;
	const orderby = orderbyRaw === "date" || orderbyRaw === "price" || orderbyRaw === "popularity" || orderbyRaw === "title" ? orderbyRaw : void 0;
	const order = orderRaw === "asc" || orderRaw === "desc" ? orderRaw : void 0;
	const pageNum = Number(search.page);
	return {
		q: typeof search.q === "string" && search.q.trim() ? search.q.trim() : void 0,
		page: Number.isFinite(pageNum) && pageNum > 1 ? Math.floor(pageNum) : void 0,
		orderby,
		order,
		on_sale: search.on_sale === true || search.on_sale === "true" ? true : void 0
	};
}
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-BkBHam3u.js
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var POPULAR = [
	"sony",
	"leica",
	"adapter",
	"macro",
	"nikon",
	"canon",
	"olympus",
	"pentax",
	"m43",
	"viltrox"
];
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "mt-auto border-t border-border bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "sm:col-span-2 lg:col-span-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl text-foreground",
						children: STORE_NAME
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xs text-sm leading-relaxed text-muted-foreground",
						children: "Camera accessories & gadgets dari Jakarta. Adapter lensa, vintage, preloved, dan aksesoris tembak-menembak yang rapi."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-muted-foreground",
					children: "Etalase"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: NAV_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/kategori/$slug",
						params: { slug: cat.slug },
						className: "hover:text-accent",
						children: cat.label
					}) }, cat.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-muted-foreground",
					children: "Toko"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toko",
							search: { page: 1 },
							className: "hover:text-accent",
							children: "Semua produk"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tentang",
							className: "hover:text-accent",
							children: "Tentang"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/unduh",
							className: "hover:text-accent",
							children: "Sumber Nuxt"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: OFFICIAL_STORE,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-accent",
							children: "citiuscam.com"
						}) })
					]
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-muted-foreground",
					children: "Kanal"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2 text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: INSTAGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-accent",
							children: "Instagram"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: TELEGRAM_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-accent",
							children: "Telegram"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: FACEBOOK_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-accent",
							children: "Facebook"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: X_URL,
							target: "_blank",
							rel: "noreferrer",
							className: "hover:text-accent",
							children: "X"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto flex max-w-6xl flex-wrap gap-x-4 gap-y-2 px-4 py-4 text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
				children: POPULAR.map((term) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/toko",
					search: {
						q: term,
						page: 1
					},
					className: "hover:text-foreground",
					children: term
				}, term))
			})
		})]
	});
}
var useCart = create()(persist((set, get) => ({
	items: [],
	add: (product, qty = 1) => {
		const priced = formatWcPrice(product.prices);
		if (get().items.find((item) => item.id === product.id)) {
			set({ items: get().items.map((item) => item.id === product.id ? {
				...item,
				qty: item.qty + qty
			} : item) });
			return;
		}
		set({ items: [...get().items, {
			id: product.id,
			slug: product.slug,
			name: product.name,
			price: priced.current,
			regularPrice: priced.regular,
			image: productImage(product, "thumb"),
			permalink: product.permalink,
			qty,
			inStock: product.is_in_stock
		}] });
	},
	setQty: (id, qty) => {
		if (qty <= 0) {
			set({ items: get().items.filter((item) => item.id !== id) });
			return;
		}
		set({ items: get().items.map((item) => item.id === id ? {
			...item,
			qty
		} : item) });
	},
	remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
	clear: () => set({ items: [] })
}), { name: "citiuscam-cart" }));
function cartCount(items) {
	return items.reduce((sum, item) => sum + item.qty, 0);
}
function cartSubtotal(items) {
	return items.reduce((sum, item) => sum + item.price * item.qty, 0);
}
var Input = import_react.forwardRef(({ className, type, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		type,
		className: cn("flex h-11 w-full rounded-md border border-border bg-surface px-3 text-sm text-foreground shadow-none transition-[border-color,box-shadow] duration-[var(--motion-quick)] placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Input.displayName = "Input";
function ApertureMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "13",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.5"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "16",
				r: "5",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.25"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M16 3.2 L19.4 11.4 L28.6 12.2 L21.6 17.8 L23.8 26.8 L16 22.2 L8.2 26.8 L10.4 17.8 L3.4 12.2 L12.6 11.4 Z",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1",
				opacity: "0.85"
			})
		]
	});
}
function SiteHeader() {
	const items = useCart((s) => s.items);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [open, setOpen] = (0, import_react.useState)(false);
	const [query, setQuery] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const count = mounted ? cartCount(items) : 0;
	(0, import_react.useEffect)(() => {
		setMounted(true);
	}, []);
	function submitSearch(event) {
		event.preventDefault();
		const q = query.trim();
		setOpen(false);
		navigate({
			to: "/toko",
			search: {
				q: q || void 0,
				page: 1
			}
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex items-center justify-center border-b border-border bg-surface px-4 py-2 text-[11px] tracking-[0.12em] text-muted-foreground",
				children: "Jakarta · Voucher 10-OFF26 · Diskon 10%"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex h-16 max-w-6xl items-center gap-4 px-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "flex size-11 items-center justify-center rounded-md text-foreground lg:hidden",
						onClick: () => setOpen((v) => !v),
						"aria-label": open ? "Tutup menu" : "Buka menu",
						children: open ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2.5 text-foreground",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ApertureMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-xl leading-none tracking-tight",
							children: STORE_NAME
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
						className: "ml-6 hidden items-center gap-5 text-sm text-muted-foreground lg:flex",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toko",
							search: { page: 1 },
							className: "hover:text-foreground",
							children: "Toko"
						}), NAV_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/kategori/$slug",
							params: { slug: cat.slug },
							className: "hover:text-foreground",
							children: cat.label
						}, cat.slug))]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-1",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
								onSubmit: submitSearch,
								className: "hidden md:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
										value: query,
										onChange: (e) => setQuery(e.target.value),
										placeholder: "Cari adapter, lensa, sony…",
										className: "h-10 w-56 bg-surface pl-9 lg:w-72",
										"aria-label": "Cari produk"
									})]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "icon",
								className: "md:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/toko",
									search: { page: 1 },
									"aria-label": "Cari",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {})
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "ghost",
								size: "icon",
								className: "relative",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/keranjang",
									"aria-label": "Keranjang",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShoppingBag, {}), count > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "absolute right-1.5 top-1.5 flex size-4 items-center justify-center rounded-full bg-accent text-[9px] font-medium text-accent-foreground tabular-nums",
										children: count
									}) : null]
								})
							})
						]
					})
				]
			}),
			open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-t border-border bg-bg px-4 py-4 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
					onSubmit: submitSearch,
					className: "mb-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: query,
							onChange: (e) => setQuery(e.target.value),
							placeholder: "Cari produk",
							className: "pl-9"
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
					className: "flex flex-col gap-1 text-base",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/toko",
							search: { page: 1 },
							className: "py-2.5",
							onClick: () => setOpen(false),
							children: "Semua produk"
						}),
						NAV_CATEGORIES.map((cat) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/kategori/$slug",
							params: { slug: cat.slug },
							className: "py-2.5 text-muted-foreground",
							onClick: () => setOpen(false),
							children: cat.label
						}, cat.slug)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/tentang",
							className: "py-2.5 text-muted-foreground",
							onClick: () => setOpen(false),
							children: "Tentang"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/unduh",
							className: "py-2.5 text-muted-foreground",
							onClick: () => setOpen(false),
							children: "Unduh sumber Nuxt"
						})
					]
				})]
			}) : null
		]
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-dvh flex-col bg-bg text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "flex-1",
				children
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
var styles_default = "/assets/styles-CxW3OmFF.css";
var APP_NAME = "CitiusCam";
var Route$8 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Headless storefront CitiusCam Jakarta — camera accessories, adapter lensa, vintage, dan preloved."
			},
			{
				name: "theme-color",
				content: "#0e0d0c"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Outfit:wght@400;500;600&display=swap"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "id",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}) }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
		] })]
	})
});
var $$splitComponentImporter$7 = () => import("./routes-BQ-mgOTD.mjs");
var Route$7 = createFileRoute("/")({
	loader: () => getCatalogHome(),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./checkout-DE-AJHwH.mjs");
var Route$6 = createFileRoute("/checkout")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./keranjang-cZ-0VRqG.mjs");
var Route$5 = createFileRoute("/keranjang")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./tentang-oa3KvStU.mjs");
var Route$4 = createFileRoute("/tentang")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./toko-hswMdLC9.mjs");
var Route$3 = createFileRoute("/toko")({
	validateSearch: (search) => parseShopSearch(search),
	loaderDeps: ({ search }) => search,
	loader: async ({ deps }) => {
		const page = deps.page ?? 1;
		const [listing, categories] = await Promise.all([listProducts({ data: {
			page,
			perPage: 12,
			search: deps.q,
			orderby: deps.orderby ?? "date",
			order: deps.order ?? (deps.orderby === "price" ? "asc" : "desc"),
			onSale: deps.on_sale
		} }), listCategories()]);
		return {
			listing,
			categories,
			page
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./unduh-CrVaMFdP.mjs");
var Route$2 = createFileRoute("/unduh")({ component: lazyRouteComponent($$splitComponentImporter$2, "component") });
var $$splitComponentImporter$1 = () => import("./kategori._slug-DQUAzafG.mjs");
var Route$1 = createFileRoute("/kategori/$slug")({
	validateSearch: (search) => parseShopSearch(search),
	loaderDeps: ({ search }) => search,
	loader: async ({ params, deps }) => {
		const categories = await listCategories();
		const category = categories.find((c) => c.slug === params.slug);
		if (!category) return {
			category: null,
			listing: {
				products: [],
				total: 0,
				totalPages: 0
			},
			page: 1,
			children: []
		};
		const page = deps.page ?? 1;
		return {
			category,
			listing: await listProducts({ data: {
				page,
				perPage: 12,
				category: category.id,
				orderby: deps.orderby ?? "date",
				order: deps.order ?? "desc",
				onSale: deps.on_sale,
				search: deps.q
			} }),
			page,
			children: categories.filter((c) => c.parent === category.id)
		};
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./produk._slug-DtULIZ1w.mjs");
var $$splitNotFoundComponentImporter = () => import("./produk._slug-BVFbw1lJ.mjs");
var Route = createFileRoute("/produk/$slug")({
	loader: async ({ params }) => {
		const product = await getProductBySlug({ data: { slug: params.slug } });
		if (!product) throw notFound();
		const relatedCat = product.categories[0]?.id;
		return {
			product,
			related: (relatedCat ? await listProducts({ data: {
				category: relatedCat,
				perPage: 8,
				orderby: "popularity"
			} }) : { products: [] }).products.filter((p) => p.id !== product.id).slice(0, 4)
		};
	},
	notFoundComponent: lazyRouteComponent($$splitNotFoundComponentImporter, "notFoundComponent"),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$7.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$8
	}),
	CheckoutRoute: Route$6.update({
		id: "/checkout",
		path: "/checkout",
		getParentRoute: () => Route$8
	}),
	KeranjangRoute: Route$5.update({
		id: "/keranjang",
		path: "/keranjang",
		getParentRoute: () => Route$8
	}),
	TentangRoute: Route$4.update({
		id: "/tentang",
		path: "/tentang",
		getParentRoute: () => Route$8
	}),
	TokoRoute: Route$3.update({
		id: "/toko",
		path: "/toko",
		getParentRoute: () => Route$8
	}),
	UnduhRoute: Route$2.update({
		id: "/unduh",
		path: "/unduh",
		getParentRoute: () => Route$8
	}),
	KategoriSlugRoute: Route$1.update({
		id: "/kategori/$slug",
		path: "/kategori/$slug",
		getParentRoute: () => Route$8
	}),
	ProdukSlugRoute: Route.update({
		id: "/produk/$slug",
		path: "/produk/$slug",
		getParentRoute: () => Route$8
	})
};
var routeTree = Route$8._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { stripHtml as C, sanitizeHtml as S, discountPercent as _, Route$7 as a, primaryCategory as b, cartSubtotal as c, cn as d, COUPON_CODE as f, decodeHtml as g, TELEGRAM_URL as h, Route$3 as i, useCart as l, OFFICIAL_STORE as m, Route as n, Input as o, INSTAGRAM_URL as p, Route$1 as r, cartCount as s, router_exports as t, Button as u, formatIdr as v, productImage as x, formatWcPrice as y };
