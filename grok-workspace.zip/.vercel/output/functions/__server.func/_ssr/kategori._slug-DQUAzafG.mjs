import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { C as stripHtml, g as decodeHtml, r as Route$1, u as Button } from "./router-BkBHam3u.mjs";
import { n as ProductGrid } from "./product-grid-CLZ7GzUg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/kategori._slug-DQUAzafG.js
var import_jsx_runtime = require_jsx_runtime();
function CategoryPage() {
	const { category, listing, page, children } = Route$1.useLoaderData();
	const search = Route$1.useSearch();
	const { slug } = Route$1.useParams();
	if (!category) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl px-4 py-20 text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl",
			children: "Kategori tidak ditemukan"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			asChild: true,
			className: "mt-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/toko",
				search: { page: 1 },
				children: "Kembali ke toko"
			})
		})]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl px-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "Kategori"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl sm:text-5xl",
				children: decodeHtml(category.name)
			}),
			category.description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-sm text-muted-foreground",
				children: stripHtml(category.description)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: [
					listing.total,
					" produk · ",
					slug
				]
			}),
			children.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 flex gap-2 overflow-x-auto pb-2",
				children: children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/kategori/$slug",
					params: { slug: child.slug },
					className: "shrink-0 rounded-full border border-border px-3 py-2 text-xs text-muted-foreground hover:text-foreground",
					children: decodeHtml(child.name)
				}, child.id))
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: listing.products })
			}),
			listing.totalPages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-12 flex items-center justify-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/kategori/$slug",
							params: { slug },
							search: {
								...search,
								page: Math.max(1, page - 1)
							},
							children: "Sebelumnya"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm tabular-nums text-muted-foreground",
						children: [
							page,
							" / ",
							listing.totalPages
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						variant: "outline",
						size: "sm",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/kategori/$slug",
							params: { slug },
							search: {
								...search,
								page: page + 1
							},
							children: "Berikutnya"
						})
					})
				]
			}) : null
		]
	});
}
//#endregion
export { CategoryPage as component };
