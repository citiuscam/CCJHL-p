import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as object, i as number, n as boolean, o as string, s as union, t as _enum } from "../_libs/zod.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-CHeOkv2w.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var WC_STORE = "https://citiuscam.com/wp-json/wc/store/v1";
var TTL_MS = 45e3;
var memory = /* @__PURE__ */ new Map();
function readCache(key) {
	const hit = memory.get(key);
	if (!hit) return null;
	if (hit.exp < Date.now()) {
		memory.delete(key);
		return null;
	}
	return hit.value;
}
function writeCache(key, value) {
	memory.set(key, {
		exp: Date.now() + TTL_MS,
		value
	});
	return value;
}
async function wcGet(path) {
	const key = path;
	const cached = readCache(key);
	if (cached) return cached;
	const url = `${WC_STORE}${path}`;
	const res = await fetch(url, { headers: { Accept: "application/json" } });
	if (!res.ok) throw new Error(`Gagal memuat katalog CitiusCam (${res.status})`);
	return writeCache(key, {
		data: await res.json(),
		total: Number(res.headers.get("X-WP-Total") ?? 0),
		totalPages: Number(res.headers.get("X-WP-TotalPages") ?? 0)
	});
}
function toQuery(params) {
	const q = new URLSearchParams();
	for (const [k, v] of Object.entries(params)) {
		if (v === void 0 || v === "" || v === false) continue;
		q.set(k, String(v));
	}
	const s = q.toString();
	return s ? `?${s}` : "";
}
var listInput = object({
	page: number().int().min(1).optional(),
	perPage: number().int().min(1).max(48).optional(),
	category: union([number(), string()]).optional(),
	search: string().max(80).optional(),
	orderby: _enum([
		"date",
		"price",
		"popularity",
		"rating",
		"title",
		"menu_order"
	]).optional(),
	order: _enum(["asc", "desc"]).optional(),
	onSale: boolean().optional(),
	stockStatus: _enum([
		"instock",
		"outofstock",
		"onbackorder"
	]).optional()
});
var listProducts_createServerFn_handler = createServerRpc({
	id: "a64943a7b8be03c561a001c2a6107debcece9fe46e620c9f49159f79a0e6e2af",
	name: "listProducts",
	filename: "src/lib/wc/api.ts"
}, (opts) => listProducts.__executeServer(opts));
var listProducts = createServerFn({ method: "GET" }).validator(listInput).handler(listProducts_createServerFn_handler, async ({ data }) => {
	const result = await wcGet(`/products${toQuery({
		page: data.page ?? 1,
		per_page: data.perPage ?? 12,
		category: data.category,
		search: data.search,
		orderby: data.orderby ?? "date",
		order: data.order ?? "desc",
		on_sale: data.onSale ? true : void 0,
		stock_status: data.stockStatus
	})}`);
	return {
		products: result.data,
		total: result.total,
		totalPages: result.totalPages
	};
});
var getProductBySlug_createServerFn_handler = createServerRpc({
	id: "120a017d43b966bb20db2094d4a901af6437181809a1abcc08b41507429f7a40",
	name: "getProductBySlug",
	filename: "src/lib/wc/api.ts"
}, (opts) => getProductBySlug.__executeServer(opts));
var getProductBySlug = createServerFn({ method: "GET" }).validator(object({ slug: string().min(1).max(200) })).handler(getProductBySlug_createServerFn_handler, async ({ data }) => {
	const match = (await wcGet(`/products${toQuery({
		slug: data.slug,
		per_page: 1
	})}`)).data.find((p) => p.slug === data.slug);
	if (match) return (await wcGet(`/products/${match.id}`)).data;
	try {
		return (await wcGet(`/products/${encodeURIComponent(data.slug)}`)).data;
	} catch {
		return null;
	}
});
var getProductById_createServerFn_handler = createServerRpc({
	id: "edcd3574333da2a171b9c6cb37ff3cfc01ecf699cd771903f5bf3079113d18c4",
	name: "getProductById",
	filename: "src/lib/wc/api.ts"
}, (opts) => getProductById.__executeServer(opts));
var getProductById = createServerFn({ method: "GET" }).validator(object({ id: number().int().positive() })).handler(getProductById_createServerFn_handler, async ({ data }) => {
	try {
		return (await wcGet(`/products/${data.id}`)).data;
	} catch {
		return null;
	}
});
var listCategories_createServerFn_handler = createServerRpc({
	id: "32fd37775d82fa29d30b03e087f017cd367a1d6f00ff4572338f70616c4005d2",
	name: "listCategories",
	filename: "src/lib/wc/api.ts"
}, (opts) => listCategories.__executeServer(opts));
var listCategories = createServerFn({ method: "GET" }).handler(listCategories_createServerFn_handler, async () => {
	return (await wcGet("/products/categories?per_page=100")).data.filter((c) => (c.count ?? 0) > 0);
});
var getCatalogHome_createServerFn_handler = createServerRpc({
	id: "2ee734da33130981caf810eab72e67aa695d3fbcadbe4ceffb6ca043c07d6008",
	name: "getCatalogHome",
	filename: "src/lib/wc/api.ts"
}, (opts) => getCatalogHome.__executeServer(opts));
var getCatalogHome = createServerFn({ method: "GET" }).handler(getCatalogHome_createServerFn_handler, async () => {
	const [latest, clearance, adapters, accessories, cameras, lenses, preloved, best, categories] = await Promise.all([
		wcGet("/products?per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=343&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=81&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=29&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=40&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=64&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=151&per_page=8&orderby=date&order=desc"),
		wcGet("/products?category=345&per_page=8&orderby=date&order=desc"),
		wcGet("/products/categories?per_page=100")
	]);
	const allLatest = await wcGet("/products?per_page=1");
	return {
		latest: latest.data,
		clearance: clearance.data,
		adapters: adapters.data,
		accessories: accessories.data,
		cameras: cameras.data,
		lenses: lenses.data,
		preloved: preloved.data.length ? preloved.data : latest.data.filter((p) => p.categories.some((c) => c.slug === "collectors-preloved" || c.slug === "hobby-gadget")),
		best: best.data,
		categories: categories.data.filter((c) => (c.count ?? 0) > 0),
		total: allLatest.total
	};
});
var searchProducts_createServerFn_handler = createServerRpc({
	id: "a7eb27003dbcafb3ba42b5b98cc0d874b8548ee50ea892aa326b9521070a3a80",
	name: "searchProducts",
	filename: "src/lib/wc/api.ts"
}, (opts) => searchProducts.__executeServer(opts));
var searchProducts = createServerFn({ method: "GET" }).validator(object({ q: string().min(1).max(80) })).handler(searchProducts_createServerFn_handler, async ({ data }) => {
	return (await wcGet(`/products${toQuery({
		search: data.q,
		per_page: 8,
		orderby: "popularity"
	})}`)).data;
});
//#endregion
export { getCatalogHome_createServerFn_handler, getProductById_createServerFn_handler, getProductBySlug_createServerFn_handler, listCategories_createServerFn_handler, listProducts_createServerFn_handler, searchProducts_createServerFn_handler };
