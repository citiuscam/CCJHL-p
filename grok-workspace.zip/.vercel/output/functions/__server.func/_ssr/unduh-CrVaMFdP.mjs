import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { u as Button } from "./router-BkBHam3u.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/unduh-CrVaMFdP.js
var import_jsx_runtime = require_jsx_runtime();
function DownloadPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-3xl px-4 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
				children: "Source"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-3 font-display text-5xl leading-tight",
				children: "Nuxt 3 storefront"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-5 text-base leading-relaxed text-muted-foreground",
				children: [
					"Paket zip berisi proyek Vue 3 / Nuxt 3 headless yang memakai WooCommerce Store API yang sama. Setelah unzip: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "text-foreground",
						children: "npm install"
					}),
					" lalu",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", {
						className: "text-foreground",
						children: "npm run dev"
					}),
					"."
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "mt-6 list-disc space-y-2 pl-5 text-sm text-muted-foreground",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Nitro proxy ke https://citiuscam.com/wp-json/wc/store/v1" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Halaman beranda, toko, kategori, produk, keranjang, checkout" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Pinia cart + Tailwind" })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				size: "lg",
				className: "mt-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "/citiuscam-nuxt-storefront.zip",
					download: true,
					children: "Unduh zip Nuxt"
				})
			})
		]
	});
}
//#endregion
export { DownloadPage as component };
