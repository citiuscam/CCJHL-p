import { S as require_jsx_runtime, y as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as Route$7, f as COUPON_CODE, g as decodeHtml, u as Button } from "./router-BkBHam3u.mjs";
import { n as ProductGrid } from "./product-grid-CLZ7GzUg.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BQ-mgOTD.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const catalog = Route$7.useLoaderData();
	const featured = catalog.latest[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-b border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-6xl items-stretch lg:grid-cols-[1.1fr_0.9fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col justify-center px-4 py-14 sm:px-8 sm:py-20",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] uppercase tracking-[0.22em] text-muted-foreground",
							children: "Jakarta · Camera house"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "mt-4 font-display text-5xl leading-[0.95] tracking-[-0.03em] text-foreground sm:text-6xl lg:text-7xl",
							children: [
								"Shoot with",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "italic",
									children: "Style"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-6 max-w-md text-base leading-relaxed text-muted-foreground",
							children: "Adapter lensa, aksesoris, vintage manual, dan barang preloved langka. Katalog live dari WooCommerce REST API CitiusCam."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/toko",
									search: { page: 1 },
									children: "Belanja sekarang"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "outline",
								size: "lg",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/kategori/$slug",
									params: { slug: "cuci-gudang" },
									children: "Cuci gudang"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-6 text-xs tracking-[0.08em] text-muted-foreground",
							children: [
								catalog.total,
								" produk · Kode voucher ",
								COUPON_CODE
							]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative min-h-72 overflow-hidden border-t border-border bg-surface lg:border-l lg:border-t-0",
					children: [featured?.images[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: featured.images[0].src,
						alt: decodeHtml(featured.name),
						className: "size-full object-cover"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-full bg-muted" }), featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-6",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[10px] uppercase tracking-[0.16em] text-muted-foreground",
							children: "Terbaru"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/produk/$slug",
							params: { slug: featured.slug },
							className: "mt-1 block font-display text-2xl leading-tight text-foreground",
							children: decodeHtml(featured.name)
						})]
					}) : null]
				})]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Baru masuk",
				title: "Produk terbaru",
				to: "/toko",
				search: {
					page: 1,
					orderby: "date"
				}
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.latest })]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border bg-surface",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-4 py-10 sm:flex-row sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.18em] text-sale",
						children: "Penawaran terbatas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "mt-2 font-display text-3xl sm:text-4xl",
						children: ["Diskon 10% dengan ", COUPON_CODE]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-lg text-sm text-muted-foreground",
						children: "Pakai kode di toko resmi CitiusCam saat checkout, atau cantumkan di pesanan Telegram."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/toko",
						search: {
							on_sale: true,
							page: 1
						},
						children: "Lihat yang diskon"
					})
				})]
			})
		}),
		catalog.clearance.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Stok gudang",
				title: "Cuci gudang",
				to: "/kategori/$slug",
				params: { slug: "cuci-gudang" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.clearance })]
		}) : null,
		catalog.adapters.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Mount",
				title: "Adapter lensa",
				to: "/kategori/$slug",
				params: { slug: "adapter-lensa" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.adapters })]
		}) : null,
		catalog.cameras.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Body",
				title: "Kamera",
				to: "/kategori/$slug",
				params: { slug: "kamera" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.cameras })]
		}) : null,
		catalog.lenses.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
				kicker: "Glass",
				title: "Lensa",
				to: "/kategori/$slug",
				params: { slug: "lensa" }
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.lenses })]
		}) : null,
		catalog.preloved.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-4 pb-20",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SectionHead, {
					kicker: "Rare",
					title: "Preloved / rare items",
					to: "/kategori/$slug",
					params: { slug: "collectors-preloved" }
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-8 max-w-xl text-sm text-muted-foreground",
					children: "Koleksi lensa antik, kamera analog, dan gadget langka — karakter foto yang tidak bisa ditiru kit modern."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductGrid, { products: catalog.preloved })
			]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl gap-px bg-border sm:grid-cols-3",
				children: [
					{
						title: "REST live",
						body: "Katalog ditarik langsung dari WooCommerce Store API citiuscam.com — stok dan harga mengikuti toko resmi."
					},
					{
						title: "Jakarta based",
						body: "CitiusCam adalah rumah aksesoris kamera di Jakarta. Adapter, hood, tutup lensa, sampai collector item."
					},
					{
						title: "Headless",
						body: "Storefront ini terpisah dari WordPress. Sumber Nuxt 3 lengkap bisa diunduh untuk deploy sendiri."
					}
				].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-bg px-6 py-10",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl",
						children: item.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm leading-relaxed text-muted-foreground",
						children: item.body
					})]
				}, item.title))
			})
		})
	] });
}
function SectionHead({ kicker, title, to, params, search }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-8 flex items-end justify-between gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.18em] text-muted-foreground",
			children: kicker
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
			className: "mt-1 font-display text-3xl sm:text-4xl",
			children: title
		})] }), to === "/toko" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/toko",
			search: search ?? { page: 1 },
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: ["Semua ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/kategori/$slug",
			params: params ?? { slug: "aksesoris" },
			className: "inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground",
			children: ["Semua ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
		})]
	});
}
//#endregion
export { Home as component };
