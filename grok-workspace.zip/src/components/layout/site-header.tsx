import { Link, useNavigate } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, X } from "lucide-react";
import { useEffect, useState, type FormEvent } from "react";
import { cartCount, useCart } from "@/lib/cart";
import { NAV_CATEGORIES, STORE_NAME } from "@/lib/wc/format";
import { Button } from "../ui/button";
import { Input } from "../ui/input";

function ApertureMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <circle cx="16" cy="16" r="13" fill="none" stroke="currentColor" strokeWidth="1.5" />
      <circle cx="16" cy="16" r="5" fill="none" stroke="currentColor" strokeWidth="1.25" />
      <path
        d="M16 3.2 L19.4 11.4 L28.6 12.2 L21.6 17.8 L23.8 26.8 L16 22.2 L8.2 26.8 L10.4 17.8 L3.4 12.2 L12.6 11.4 Z"
        fill="none"
        stroke="currentColor"
        strokeWidth="1"
        opacity="0.85"
      />
    </svg>
  );
}

export function SiteHeader() {
  const items = useCart((s) => s.items);
  const [mounted, setMounted] = useState(false);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  const count = mounted ? cartCount(items) : 0;

  useEffect(() => {
    setMounted(true);
  }, []);

  function submitSearch(event: FormEvent) {
    event.preventDefault();
    const q = query.trim();
    setOpen(false);
    void navigate({ to: "/toko", search: { q: q || undefined, page: 1 } });
  }

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg/90 backdrop-blur-md">
      <div className="flex items-center justify-center border-b border-border bg-surface px-4 py-2 text-[11px] tracking-[0.12em] text-muted-foreground">
        Jakarta · Voucher 10-OFF26 · Diskon 10%
      </div>
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-md text-foreground lg:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label={open ? "Tutup menu" : "Buka menu"}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>

        <Link to="/" className="flex items-center gap-2.5 text-foreground">
          <ApertureMark className="size-7" />
          <span className="font-display text-xl leading-none tracking-tight">{STORE_NAME}</span>
        </Link>

        <nav className="ml-6 hidden items-center gap-5 text-sm text-muted-foreground lg:flex">
          <Link to="/toko" search={{ page: 1 }} className="hover:text-foreground">
            Toko
          </Link>
          {NAV_CATEGORIES.map((cat) => (
            <Link
              key={cat.slug}
              to="/kategori/$slug"
              params={{ slug: cat.slug }}
              className="hover:text-foreground"
            >
              {cat.label}
            </Link>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-1">
          <form onSubmit={submitSearch} className="hidden md:block">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari adapter, lensa, sony…"
                className="h-10 w-56 bg-surface pl-9 lg:w-72"
                aria-label="Cari produk"
              />
            </div>
          </form>
          <Button asChild variant="ghost" size="icon" className="md:hidden">
            <Link to="/toko" search={{ page: 1 }} aria-label="Cari">
              <Search />
            </Link>
          </Button>
          <Button asChild variant="ghost" size="icon" className="relative">
            <Link to="/keranjang" aria-label="Keranjang">
              <ShoppingBag />
              {count > 0 ? (
                <span className="absolute right-1.5 top-1.5 flex size-4 items-center justify-center rounded-full bg-accent text-[9px] font-medium text-accent-foreground tabular-nums">
                  {count}
                </span>
              ) : null}
            </Link>
          </Button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border bg-bg px-4 py-4 lg:hidden">
          <form onSubmit={submitSearch} className="mb-4">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Cari produk"
                className="pl-9"
              />
            </div>
          </form>
          <nav className="flex flex-col gap-1 text-base">
            <Link to="/toko" search={{ page: 1 }} className="py-2.5" onClick={() => setOpen(false)}>
              Semua produk
            </Link>
            {NAV_CATEGORIES.map((cat) => (
              <Link
                key={cat.slug}
                to="/kategori/$slug"
                params={{ slug: cat.slug }}
                className="py-2.5 text-muted-foreground"
                onClick={() => setOpen(false)}
              >
                {cat.label}
              </Link>
            ))}
            <Link to="/tentang" className="py-2.5 text-muted-foreground" onClick={() => setOpen(false)}>
              Tentang
            </Link>
            <Link to="/unduh" className="py-2.5 text-muted-foreground" onClick={() => setOpen(false)}>
              Unduh sumber Nuxt
            </Link>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
