import { Link } from "@tanstack/react-router";
import { FACEBOOK_URL, INSTAGRAM_URL, NAV_CATEGORIES, OFFICIAL_STORE, STORE_NAME, TELEGRAM_URL, X_URL } from "@/lib/wc/format";

const POPULAR = ["sony", "leica", "adapter", "macro", "nikon", "canon", "olympus", "pentax", "m43", "viltrox"];

export function SiteFooter() {
  return (
    <footer className="mt-auto border-t border-border bg-surface">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-14 sm:grid-cols-2 lg:grid-cols-4">
        <div className="sm:col-span-2 lg:col-span-1">
          <p className="font-display text-2xl text-foreground">{STORE_NAME}</p>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted-foreground">
            Camera accessories & gadgets dari Jakarta. Adapter lensa, vintage, preloved, dan aksesoris
            tembak-menembak yang rapi.
          </p>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Etalase</p>
          <ul className="mt-4 space-y-2 text-sm">
            {NAV_CATEGORIES.map((cat) => (
              <li key={cat.slug}>
                <Link to="/kategori/$slug" params={{ slug: cat.slug }} className="hover:text-accent">
                  {cat.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Toko</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <Link to="/toko" search={{ page: 1 }} className="hover:text-accent">
                Semua produk
              </Link>
            </li>
            <li>
              <Link to="/tentang" className="hover:text-accent">
                Tentang
              </Link>
            </li>
            <li>
              <Link to="/unduh" className="hover:text-accent">
                Sumber Nuxt
              </Link>
            </li>
            <li>
              <a href={OFFICIAL_STORE} target="_blank" rel="noreferrer" className="hover:text-accent">
                citiuscam.com
              </a>
            </li>
          </ul>
        </div>
        <div>
          <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">Kanal</p>
          <ul className="mt-4 space-y-2 text-sm">
            <li>
              <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer" className="hover:text-accent">
                Instagram
              </a>
            </li>
            <li>
              <a href={TELEGRAM_URL} target="_blank" rel="noreferrer" className="hover:text-accent">
                Telegram
              </a>
            </li>
            <li>
              <a href={FACEBOOK_URL} target="_blank" rel="noreferrer" className="hover:text-accent">
                Facebook
              </a>
            </li>
            <li>
              <a href={X_URL} target="_blank" rel="noreferrer" className="hover:text-accent">
                X
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-wrap gap-x-4 gap-y-2 px-4 py-4 text-[11px] uppercase tracking-[0.12em] text-muted-foreground">
          {POPULAR.map((term) => (
            <Link key={term} to="/toko" search={{ q: term, page: 1 }} className="hover:text-foreground">
              {term}
            </Link>
          ))}
        </div>
      </div>
    </footer>
  );
}
