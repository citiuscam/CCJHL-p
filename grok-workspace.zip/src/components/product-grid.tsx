import type { WcProduct } from "@/lib/wc/types";
import { ProductCard } from "./product-card";

export function ProductGrid({ products }: { products: WcProduct[] }) {
  if (!products.length) {
    return (
      <p className="py-16 text-center text-sm text-muted-foreground">
        Belum ada produk pada etalase ini.
      </p>
    );
  }

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  );
}
