import { Link } from "@tanstack/react-router";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart";
import { decodeHtml, discountPercent, formatWcPrice, primaryCategory, productImage } from "@/lib/wc/format";
import type { WcProduct } from "@/lib/wc/types";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

export function ProductCard({ product }: { product: WcProduct }) {
  const add = useCart((s) => s.add);
  const priced = formatWcPrice(product.prices);
  const off = discountPercent(product.prices);
  const image = productImage(product);
  const category = primaryCategory(product);

  return (
    <article className="group flex flex-col">
      <Link
        to="/produk/$slug"
        params={{ slug: product.slug }}
        className="relative block overflow-hidden rounded-xl bg-surface"
      >
        <div className="aspect-[4/5] overflow-hidden">
          {image ? (
            <img
              src={image}
              alt={decodeHtml(product.images[0]?.alt || product.name)}
              className="size-full object-cover transition-transform duration-[var(--motion-slow)] ease-[var(--ease-smooth-out)] group-hover:scale-[1.04]"
              loading="lazy"
            />
          ) : (
            <div className="flex size-full items-center justify-center bg-muted text-muted-foreground">
              <ShoppingBag className="size-8" strokeWidth={1.25} />
            </div>
          )}
        </div>
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {off ? <Badge variant="sale">-{off}%</Badge> : null}
          {!product.is_in_stock ? <Badge variant="outline">Habis</Badge> : null}
        </div>
      </Link>
      <div className="flex flex-1 flex-col gap-2 pt-3">
        <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">{category}</p>
        <Link
          to="/produk/$slug"
          params={{ slug: product.slug }}
          className="line-clamp-2 min-h-10 text-sm font-medium leading-snug text-foreground text-balance hover:text-accent"
        >
          {decodeHtml(product.name)}
        </Link>
        <div className="mt-auto flex items-end justify-between gap-3 pt-1">
          <div className="flex flex-col">
            <span className="font-medium tabular-nums text-foreground">{priced.label}</span>
            {priced.onSale ? (
              <span className="text-xs tabular-nums text-muted-foreground line-through">
                {priced.regularLabel}
              </span>
            ) : null}
          </div>
          <Button
            size="icon"
            variant="secondary"
            className="size-10 shrink-0 rounded-lg"
            disabled={!product.is_purchasable || !product.is_in_stock}
            aria-label={`Tambah ${decodeHtml(product.name)} ke keranjang`}
            onClick={() => add(product)}
          >
            <ShoppingBag strokeWidth={1.75} />
          </Button>
        </div>
      </div>
    </article>
  );
}
