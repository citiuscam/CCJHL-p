import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { QtyStepper } from "@/components/qty-stepper";
import { Button } from "@/components/ui/button";
import { cartCount, cartSubtotal, useCart } from "@/lib/cart";
import { formatIdr } from "@/lib/wc/format";

export const Route = createFileRoute("/keranjang")({
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove } = useCart();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  if (!mounted) {
    return <div className="mx-auto max-w-4xl px-4 py-16 text-sm text-muted-foreground">Memuat keranjang…</div>;
  }

  if (!items.length) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <h1 className="font-display text-4xl">Keranjang kosong</h1>
        <p className="mt-3 text-sm text-muted-foreground">Belum ada gear. Mulai dari etalase.</p>
        <Button asChild className="mt-8">
          <Link to="/toko" search={{ page: 1 }}>
            Belanja
          </Link>
        </Button>
      </div>
    );
  }

  const total = cartSubtotal(items);

  return (
    <div className="mx-auto max-w-4xl px-4 py-10">
      <h1 className="font-display text-4xl">Keranjang</h1>
      <p className="mt-2 text-sm text-muted-foreground">{cartCount(items)} item</p>
      <ul className="mt-8 divide-y divide-border border-y border-border">
        {items.map((item) => (
          <li key={item.id} className="flex gap-4 py-5">
            <Link to="/produk/$slug" params={{ slug: item.slug }} className="size-24 shrink-0 overflow-hidden rounded-lg bg-surface">
              {item.image ? (
                <img src={item.image} alt="" className="size-full object-cover" />
              ) : null}
            </Link>
            <div className="flex min-w-0 flex-1 flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
              <div className="min-w-0">
                <Link to="/produk/$slug" params={{ slug: item.slug }} className="line-clamp-2 text-sm font-medium">
                  {item.name}
                </Link>
                <p className="mt-1 text-sm tabular-nums text-muted-foreground">{formatIdr(item.price)}</p>
                <button
                  type="button"
                  className="mt-2 text-xs text-muted-foreground underline-offset-2 hover:underline"
                  onClick={() => remove(item.id)}
                >
                  Hapus
                </button>
              </div>
              <div className="flex items-center justify-between gap-4">
                <QtyStepper value={item.qty} onChange={(n) => setQty(item.id, n)} />
                <p className="w-28 text-right text-sm font-medium tabular-nums">
                  {formatIdr(item.price * item.qty)}
                </p>
              </div>
            </div>
          </li>
        ))}
      </ul>
      <div className="mt-8 flex flex-col items-stretch justify-between gap-4 sm:flex-row sm:items-center">
        <p className="text-lg">
          Subtotal <span className="font-medium tabular-nums">{formatIdr(total)}</span>
        </p>
        <Button asChild size="lg">
          <Link to="/checkout">Lanjut checkout</Link>
        </Button>
      </div>
    </div>
  );
}
