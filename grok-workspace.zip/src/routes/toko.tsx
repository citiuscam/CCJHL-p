import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { ProductGrid } from "@/components/product-grid";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { parseShopSearch, type ShopSearch } from "@/lib/shop-search";
import { listCategories, listProducts } from "@/lib/wc/api";
import { decodeHtml } from "@/lib/wc/format";

export const Route = createFileRoute("/toko")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => parseShopSearch(search),
  loaderDeps: ({ search }) => search,
  loader: async ({ deps }) => {
    const page = deps.page ?? 1;
    const [listing, categories] = await Promise.all([
      listProducts({
        data: {
          page,
          perPage: 12,
          search: deps.q,
          orderby: deps.orderby ?? "date",
          order: deps.order ?? (deps.orderby === "price" ? "asc" : "desc"),
          onSale: deps.on_sale,
        },
      }),
      listCategories(),
    ]);
    return { listing, categories, page };
  },
  component: ShopPage,
});

function ShopPage() {
  const { listing, categories, page } = Route.useLoaderData();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/toko" });
  const [q, setQ] = useState(search.q ?? "");
  const [orderby, setOrderby] = useState(search.orderby ?? "date");
  const parentCats = categories.filter((c) => !c.parent && (c.count ?? 0) > 0);

  function onFilter(event: FormEvent) {
    event.preventDefault();
    void navigate({
      search: {
        q: q.trim() || undefined,
        orderby: orderby === "date" ? undefined : orderby,
        page: 1,
        on_sale: search.on_sale,
      },
    });
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Etalase</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">Semua produk</h1>
      <p className="mt-3 text-sm text-muted-foreground">
        {listing.total} item dari WooCommerce Store API · halaman {page} / {Math.max(1, listing.totalPages)}
      </p>

      <form className="mt-8 flex flex-col gap-3 sm:flex-row" onSubmit={onFilter}>
        <Input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Cari sony, adapter, leica…"
          className="sm:max-w-sm"
        />
        <select
          value={orderby}
          onChange={(e) => setOrderby(e.target.value as NonNullable<ShopSearch["orderby"]>)}
          className="h-11 rounded-md border border-border bg-surface px-3 text-sm text-foreground"
        >
          <option value="date">Terbaru</option>
          <option value="popularity">Terpopuler</option>
          <option value="price">Harga</option>
          <option value="title">Nama</option>
        </select>
        <Button type="submit">Terapkan</Button>
      </form>

      <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
        <FilterChip to="/toko" search={{ page: 1 }} active={!search.q && !search.on_sale}>
          Semua
        </FilterChip>
        <FilterChip to="/toko" search={{ on_sale: true, page: 1 }} active={!!search.on_sale}>
          Diskon
        </FilterChip>
        {parentCats.slice(0, 10).map((cat) => (
          <Link
            key={cat.id}
            to="/kategori/$slug"
            params={{ slug: cat.slug }}
            className="shrink-0 rounded-full border border-border px-3 py-2 text-xs text-muted-foreground hover:text-foreground"
          >
            {decodeHtml(cat.name)}
          </Link>
        ))}
      </div>

      <div className="mt-10">
        <ProductGrid products={listing.products} />
      </div>

      {listing.totalPages > 1 ? (
        <div className="mt-12 flex items-center justify-center gap-3">
          <Button asChild variant="outline" size="sm" className={page <= 1 ? "pointer-events-none opacity-40" : ""}>
            <Link to="/toko" search={{ ...search, page: Math.max(1, page - 1) }}>
              Sebelumnya
            </Link>
          </Button>
          <span className="text-sm tabular-nums text-muted-foreground">
            {page} / {listing.totalPages}
          </span>
          <Button
            asChild
            variant="outline"
            size="sm"
            className={page >= listing.totalPages ? "pointer-events-none opacity-40" : ""}
          >
            <Link to="/toko" search={{ ...search, page: page + 1 }}>
              Berikutnya
            </Link>
          </Button>
        </div>
      ) : null}
    </div>
  );
}

function FilterChip({
  children,
  to,
  search,
  active,
}: {
  children: string;
  to: "/toko";
  search: ShopSearch;
  active: boolean;
}) {
  return (
    <Link
      to={to}
      search={search}
      className={`shrink-0 rounded-full border px-3 py-2 text-xs ${
        active
          ? "border-foreground bg-foreground text-bg"
          : "border-border text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </Link>
  );
}
