import { createFileRoute } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/unduh")({
  component: DownloadPage,
});

function DownloadPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-14">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Source</p>
      <h1 className="mt-3 font-display text-5xl leading-tight">Nuxt 3 storefront</h1>
      <p className="mt-5 text-base leading-relaxed text-muted-foreground">
        Paket zip berisi proyek Vue 3 / Nuxt 3 headless yang memakai WooCommerce Store API yang sama.
        Setelah unzip: <code className="text-foreground">npm install</code> lalu{" "}
        <code className="text-foreground">npm run dev</code>.
      </p>
      <ul className="mt-6 list-disc space-y-2 pl-5 text-sm text-muted-foreground">
        <li>Nitro proxy ke https://citiuscam.com/wp-json/wc/store/v1</li>
        <li>Halaman beranda, toko, kategori, produk, keranjang, checkout</li>
        <li>Pinia cart + Tailwind</li>
      </ul>
      <Button asChild size="lg" className="mt-8">
        <a href="/citiuscam-nuxt-storefront.zip" download>
          Unduh zip Nuxt
        </a>
      </Button>
    </article>
  );
}
