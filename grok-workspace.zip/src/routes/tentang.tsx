import { createFileRoute } from "@tanstack/react-router";
import { INSTAGRAM_URL, OFFICIAL_STORE, TELEGRAM_URL } from "@/lib/wc/format";

export const Route = createFileRoute("/tentang")({
  component: AboutPage,
});

function AboutPage() {
  return (
    <article className="mx-auto max-w-3xl px-4 py-14">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">CitiusCam Jakarta</p>
      <h1 className="mt-3 font-display text-5xl leading-tight">Shoot with Style</h1>
      <div className="mt-8 space-y-5 text-base leading-relaxed text-muted-foreground">
        <p>
          CitiusCam adalah rumah aksesoris kamera dan gadget di Jakarta — adapter lensa lintas mount,
          hood, tutup body, remote, flash, sampai lensa manual antik dan barang collector.
        </p>
        <p>
          Storefront ini headless: katalog, harga, dan stok ditarik live dari WooCommerce Store REST
          API <code className="text-foreground">/wp-json/wc/store/v1</code> milik citiuscam.com. Tidak
          ada dummy catalog.
        </p>
        <p>
          Keranjang disimpan di perangkat Anda. Checkout mengirim ringkasan ke Telegram resmi, lalu
          pembayaran dan pengiriman diselesaikan di toko WordPress.
        </p>
      </div>
      <div className="mt-10 flex flex-wrap gap-4 text-sm">
        <a href={OFFICIAL_STORE} className="text-accent underline-offset-4 hover:underline" target="_blank" rel="noreferrer">
          citiuscam.com
        </a>
        <a href={INSTAGRAM_URL} className="text-accent underline-offset-4 hover:underline" target="_blank" rel="noreferrer">
          Instagram
        </a>
        <a href={TELEGRAM_URL} className="text-accent underline-offset-4 hover:underline" target="_blank" rel="noreferrer">
          Telegram
        </a>
      </div>
    </article>
  );
}
