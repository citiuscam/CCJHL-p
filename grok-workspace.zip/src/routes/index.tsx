import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { ProductGrid } from "@/components/product-grid";
import { Button } from "@/components/ui/button";
import { getCatalogHome } from "@/lib/wc/api";
import { COUPON_CODE, decodeHtml } from "@/lib/wc/format";

export const Route = createFileRoute("/")({
  loader: () => getCatalogHome(),
  component: Home,
});

function Home() {
  const catalog = Route.useLoaderData();
  const featured = catalog.latest[0];

  return (
    <div>
      <section className="border-b border-border">
        <div className="mx-auto grid max-w-6xl items-stretch lg:grid-cols-[1.1fr_0.9fr]">
          <div className="flex flex-col justify-center px-4 py-14 sm:px-8 sm:py-20">
            <p className="text-[11px] uppercase tracking-[0.22em] text-muted-foreground">
              Jakarta · Camera house
            </p>
            <h1 className="mt-4 font-display text-5xl leading-[0.95] tracking-[-0.03em] text-foreground sm:text-6xl lg:text-7xl">
              Shoot with
              <br />
              <span className="italic">Style</span>
            </h1>
            <p className="mt-6 max-w-md text-base leading-relaxed text-muted-foreground">
              Adapter lensa, aksesoris, vintage manual, dan barang preloved langka. Katalog live dari
              WooCommerce REST API CitiusCam.
            </p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Button asChild size="lg">
                <Link to="/toko" search={{ page: 1 }}>
                  Belanja sekarang
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/kategori/$slug" params={{ slug: "cuci-gudang" }}>
                  Cuci gudang
                </Link>
              </Button>
            </div>
            <p className="mt-6 text-xs tracking-[0.08em] text-muted-foreground">
              {catalog.total} produk · Kode voucher {COUPON_CODE}
            </p>
          </div>
          <div className="relative min-h-72 overflow-hidden border-t border-border bg-surface lg:border-l lg:border-t-0">
            {featured?.images[0] ? (
              <img
                src={featured.images[0].src}
                alt={decodeHtml(featured.name)}
                className="size-full object-cover"
              />
            ) : (
              <div className="size-full bg-muted" />
            )}
            {featured ? (
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/90 to-transparent p-6">
                <p className="text-[10px] uppercase tracking-[0.16em] text-muted-foreground">Terbaru</p>
                <Link
                  to="/produk/$slug"
                  params={{ slug: featured.slug }}
                  className="mt-1 block font-display text-2xl leading-tight text-foreground"
                >
                  {decodeHtml(featured.name)}
                </Link>
              </div>
            ) : null}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <SectionHead
          kicker="Baru masuk"
          title="Produk terbaru"
          to="/toko"
          search={{ page: 1, orderby: "date" }}
        />
        <ProductGrid products={catalog.latest} />
      </section>

      <section className="border-y border-border bg-surface">
        <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-6 px-4 py-10 sm:flex-row sm:items-center">
          <div>
            <p className="text-[11px] uppercase tracking-[0.18em] text-sale">Penawaran terbatas</p>
            <h2 className="mt-2 font-display text-3xl sm:text-4xl">Diskon 10% dengan {COUPON_CODE}</h2>
            <p className="mt-2 max-w-lg text-sm text-muted-foreground">
              Pakai kode di toko resmi CitiusCam saat checkout, atau cantumkan di pesanan Telegram.
            </p>
          </div>
          <Button asChild>
            <Link to="/toko" search={{ on_sale: true, page: 1 }}>
              Lihat yang diskon
            </Link>
          </Button>
        </div>
      </section>

      {catalog.clearance.length ? (
        <section className="mx-auto max-w-6xl px-4 py-16">
          <SectionHead
            kicker="Stok gudang"
            title="Cuci gudang"
            to="/kategori/$slug"
            params={{ slug: "cuci-gudang" }}
          />
          <ProductGrid products={catalog.clearance} />
        </section>
      ) : null}

      {catalog.adapters.length ? (
        <section className="mx-auto max-w-6xl px-4 pb-16">
          <SectionHead
            kicker="Mount"
            title="Adapter lensa"
            to="/kategori/$slug"
            params={{ slug: "adapter-lensa" }}
          />
          <ProductGrid products={catalog.adapters} />
        </section>
      ) : null}

      {catalog.cameras.length ? (
        <section className="mx-auto max-w-6xl px-4 pb-16">
          <SectionHead
            kicker="Body"
            title="Kamera"
            to="/kategori/$slug"
            params={{ slug: "kamera" }}
          />
          <ProductGrid products={catalog.cameras} />
        </section>
      ) : null}

      {catalog.lenses.length ? (
        <section className="mx-auto max-w-6xl px-4 pb-16">
          <SectionHead kicker="Glass" title="Lensa" to="/kategori/$slug" params={{ slug: "lensa" }} />
          <ProductGrid products={catalog.lenses} />
        </section>
      ) : null}

      {catalog.preloved.length ? (
        <section className="mx-auto max-w-6xl px-4 pb-20">
          <SectionHead
            kicker="Rare"
            title="Preloved / rare items"
            to="/kategori/$slug"
            params={{ slug: "collectors-preloved" }}
          />
          <p className="mb-8 max-w-xl text-sm text-muted-foreground">
            Koleksi lensa antik, kamera analog, dan gadget langka — karakter foto yang tidak bisa
            ditiru kit modern.
          </p>
          <ProductGrid products={catalog.preloved} />
        </section>
      ) : null}

      <section className="border-t border-border">
        <div className="mx-auto grid max-w-6xl gap-px bg-border sm:grid-cols-3">
          {[
            {
              title: "REST live",
              body: "Katalog ditarik langsung dari WooCommerce Store API citiuscam.com — stok dan harga mengikuti toko resmi.",
            },
            {
              title: "Jakarta based",
              body: "CitiusCam adalah rumah aksesoris kamera di Jakarta. Adapter, hood, tutup lensa, sampai collector item.",
            },
            {
              title: "Headless",
              body: "Storefront ini terpisah dari WordPress. Sumber Nuxt 3 lengkap bisa diunduh untuk deploy sendiri.",
            },
          ].map((item) => (
            <div key={item.title} className="bg-bg px-6 py-10">
              <h3 className="font-display text-2xl">{item.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">{item.body}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

function SectionHead({
  kicker,
  title,
  to,
  params,
  search,
}: {
  kicker: string;
  title: string;
  to: "/toko" | "/kategori/$slug";
  params?: { slug: string };
  search?: { page?: number; orderby?: "date" | "price" | "popularity" | "title"; on_sale?: boolean };
}) {
  return (
    <div className="mb-8 flex items-end justify-between gap-4">
      <div>
        <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">{kicker}</p>
        <h2 className="mt-1 font-display text-3xl sm:text-4xl">{title}</h2>
      </div>
      {to === "/toko" ? (
        <Link
          to="/toko"
          search={search ?? { page: 1 }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          Semua <ArrowRight className="size-4" />
        </Link>
      ) : (
        <Link
          to="/kategori/$slug"
          params={params ?? { slug: "aksesoris" }}
          className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          Semua <ArrowRight className="size-4" />
        </Link>
      )}
    </div>
  );
}
