import { createFileRoute, Link } from "@tanstack/react-router";
import { ProductGrid } from "@/components/product-grid";
import { Button } from "@/components/ui/button";
import { parseShopSearch, type ShopSearch } from "@/lib/shop-search";
import { listCategories, listProducts } from "@/lib/wc/api";
import { decodeHtml, stripHtml } from "@/lib/wc/format";

export const Route = createFileRoute("/kategori/$slug")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => parseShopSearch(search),
  loaderDeps: ({ search }) => search,
  loader: async ({ params, deps }) => {
    const categories = await listCategories();
    const category = categories.find((c) => c.slug === params.slug);
    if (!category) {
      return { category: null, listing: { products: [], total: 0, totalPages: 0 }, page: 1, children: [] };
    }
    const page = deps.page ?? 1;
    const listing = await listProducts({
      data: {
        page,
        perPage: 12,
        category: category.id,
        orderby: deps.orderby ?? "date",
        order: deps.order ?? "desc",
        onSale: deps.on_sale,
        search: deps.q,
      },
    });
    const children = categories.filter((c) => c.parent === category.id);
    return { category, listing, page, children };
  },
  component: CategoryPage,
});

function CategoryPage() {
  const { category, listing, page, children } = Route.useLoaderData();
  const search = Route.useSearch();
  const { slug } = Route.useParams();

  if (!category) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-20 text-center">
        <h1 className="font-display text-4xl">Kategori tidak ditemukan</h1>
        <Button asChild className="mt-6">
          <Link to="/toko" search={{ page: 1 }}>
            Kembali ke toko
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <p className="text-[11px] uppercase tracking-[0.18em] text-muted-foreground">Kategori</p>
      <h1 className="mt-2 font-display text-4xl sm:text-5xl">{decodeHtml(category.name)}</h1>
      {category.description ? (
        <p className="mt-3 max-w-2xl text-sm text-muted-foreground">{stripHtml(category.description)}</p>
      ) : null}
      <p className="mt-2 text-sm text-muted-foreground">
        {listing.total} produk · {slug}
      </p>

      {children.length ? (
        <div className="mt-6 flex gap-2 overflow-x-auto pb-2">
          {children.map((child) => (
            <Link
              key={child.id}
              to="/kategori/$slug"
              params={{ slug: child.slug }}
              className="shrink-0 rounded-full border border-border px-3 py-2 text-xs text-muted-foreground hover:text-foreground"
            >
              {decodeHtml(child.name)}
            </Link>
          ))}
        </div>
      ) : null}

      <div className="mt-10">
        <ProductGrid products={listing.products} />
      </div>

      {listing.totalPages > 1 ? (
        <div className="mt-12 flex items-center justify-center gap-3">
          <Button asChild variant="outline" size="sm">
            <Link
              to="/kategori/$slug"
              params={{ slug }}
              search={{ ...search, page: Math.max(1, page - 1) }}
            >
              Sebelumnya
            </Link>
          </Button>
          <span className="text-sm tabular-nums text-muted-foreground">
            {page} / {listing.totalPages}
          </span>
          <Button asChild variant="outline" size="sm">
            <Link to="/kategori/$slug" params={{ slug }} search={{ ...search, page: page + 1 }}>
              Berikutnya
            </Link>
          </Button>
        </div>
      ) : null}
    </div>
  );
}
