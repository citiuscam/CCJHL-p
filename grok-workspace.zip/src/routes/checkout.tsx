import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cartSubtotal, useCart } from "@/lib/cart";
import { COUPON_CODE, formatIdr, OFFICIAL_STORE, TELEGRAM_URL } from "@/lib/wc/format";

export const Route = createFileRoute("/checkout")({
  component: CheckoutPage,
});

function CheckoutPage() {
  const items = useCart((s) => s.items);
  const clear = useCart((s) => s.clear);
  const [mounted, setMounted] = useState(false);
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [city, setCity] = useState("Jakarta");
  const [note, setNote] = useState("");
  const [sent, setSent] = useState(false);

  useEffect(() => setMounted(true), []);

  const message = useMemo(() => {
    const lines = items.map(
      (item) => `- ${item.name} × ${item.qty} @ ${formatIdr(item.price)}`,
    );
    return [
      `Pesanan CitiusCam`,
      `Nama: ${name || "-"}`,
      `WA: ${phone || "-"}`,
      `Kota: ${city || "-"}`,
      ``,
      ...lines,
      ``,
      `Subtotal: ${formatIdr(cartSubtotal(items))}`,
      `Voucher: ${COUPON_CODE}`,
      note ? `Catatan: ${note}` : "",
    ]
      .filter(Boolean)
      .join("\n");
  }, [items, name, phone, city, note]);

  if (!mounted) return null;

  if (!items.length && !sent) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <h1 className="font-display text-4xl">Keranjang kosong</h1>
        <Button asChild className="mt-8">
          <Link to="/toko" search={{ page: 1 }}>
            Belanja
          </Link>
        </Button>
      </div>
    );
  }

  if (sent) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <h1 className="font-display text-4xl">Pesanan siap dikirim</h1>
        <p className="mt-3 text-sm text-muted-foreground">
          Lanjutkan di Telegram CitiusCam atau selesaikan di toko resmi.
        </p>
        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <Button asChild>
            <a href={`${TELEGRAM_URL}?text=${encodeURIComponent(message)}`} target="_blank" rel="noreferrer">
              Buka Telegram
            </a>
          </Button>
          <Button asChild variant="outline">
            <a href={OFFICIAL_STORE} target="_blank" rel="noreferrer">
              citiuscam.com
            </a>
          </Button>
        </div>
      </div>
    );
  }

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    const url = `${TELEGRAM_URL}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    setSent(true);
    clear();
  }

  return (
    <div className="mx-auto grid max-w-5xl gap-10 px-4 py-10 lg:grid-cols-[1fr_0.85fr]">
      <form onSubmit={onSubmit} className="space-y-4">
        <h1 className="font-display text-4xl">Checkout</h1>
        <p className="text-sm text-muted-foreground">
          Headless checkout mengirim ringkasan ke Telegram @citiuscam. Pembayaran dan pengiriman
          diselesaikan oleh toko resmi. Voucher {COUPON_CODE} berlaku di citiuscam.com.
        </p>
        <label className="block text-sm">
          Nama
          <Input value={name} onChange={(e) => setName(e.target.value)} required className="mt-1.5" />
        </label>
        <label className="block text-sm">
          WhatsApp / telepon
          <Input value={phone} onChange={(e) => setPhone(e.target.value)} required className="mt-1.5" />
        </label>
        <label className="block text-sm">
          Kota
          <Input value={city} onChange={(e) => setCity(e.target.value)} required className="mt-1.5" />
        </label>
        <label className="block text-sm">
          Catatan
          <Input value={note} onChange={(e) => setNote(e.target.value)} className="mt-1.5" />
        </label>
        <Button type="submit" size="lg" className="w-full sm:w-auto">
          Kirim pesanan via Telegram
        </Button>
      </form>

      <aside className="rounded-xl border border-border bg-surface p-5">
        <h2 className="font-display text-2xl">Ringkasan</h2>
        <ul className="mt-4 space-y-3 text-sm">
          {items.map((item) => (
            <li key={item.id} className="flex justify-between gap-3">
              <span className="line-clamp-2 text-muted-foreground">
                {item.name} × {item.qty}
              </span>
              <span className="tabular-nums">{formatIdr(item.price * item.qty)}</span>
            </li>
          ))}
        </ul>
        <div className="mt-6 flex justify-between border-t border-border pt-4 text-sm font-medium">
          <span>Subtotal</span>
          <span className="tabular-nums">{formatIdr(cartSubtotal(items))}</span>
        </div>
        <p className="mt-4 text-xs text-muted-foreground">
          Ongkir dihitung toko resmi. Cantumkan {COUPON_CODE} untuk 10% off.
        </p>
        <ul className="mt-4 space-y-2 text-xs">
          {items.map((item) => (
            <li key={`off-${item.id}`}>
              <a href={item.permalink} className="text-accent underline-offset-2 hover:underline" target="_blank" rel="noreferrer">
                Buka {item.name.slice(0, 40)} di toko resmi
              </a>
            </li>
          ))}
        </ul>
      </aside>
    </div>
  );
}
