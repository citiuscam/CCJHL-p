import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useState } from "react";
import { QtyStepper } from "@/components/qty-stepper";
import { ProductGrid } from "@/components/product-grid";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useCart } from "@/lib/cart";
import { getProductBySlug, listProducts } from "@/lib/wc/api";
import {
  decodeHtml,
  discountPercent,
  formatWcPrice,
  OFFICIAL_STORE,
  primaryCategory,
  sanitizeHtml,
  stripHtml,
} from "@/lib/wc/format";

export const Route = createFileRoute("/produk/$slug")({
  loader: async ({ params }) => {
    const product = await getProductBySlug({ data: { slug: params.slug } });
    if (!product) throw notFound();
    const relatedCat = product.categories[0]?.id;
    const related = relatedCat
      ? await listProducts({
          data: { category: relatedCat, perPage: 8, orderby: "popularity" },
        })
      : { products: [] };
    return {
      product,
      related: related.products.filter((p) => p.id !== product.id).slice(0, 4),
    };
  },
  notFoundComponent: () => (
    <div className="mx-auto max-w-3xl px-4 py-20 text-center">
      <h1 className="font-display text-4xl">Produk tidak ditemukan</h1>
      <Button asChild className="mt-6">
        <Link to="/toko" search={{ page: 1 }}>
          Kembali ke toko
        </Link>
      </Button>
    </div>
  ),
  component: ProductPage,
});

function ProductPage() {
  const { product, related } = Route.useLoaderData();
  const add = useCart((s) => s.add);
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);
  const priced = formatWcPrice(product.prices);
  const off = discountPercent(product.prices);
  const images = product.images.length ? product.images : [];
  const current = images[active] ?? images[0];

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <p className="text-[11px] uppercase tracking-[0.16em] text-muted-foreground">
        <Link to="/toko" search={{ page: 1 }} className="hover:text-foreground">
          Toko
        </Link>
        <span className="mx-2">/</span>
        {primaryCategory(product)}
      </p>

      <div className="mt-6 grid gap-10 lg:grid-cols-2">
        <div>
          <div className="overflow-hidden rounded-xl bg-surface">
            {current ? (
              <img
                src={current.src}
                alt={decodeHtml(current.alt || product.name)}
                className="aspect-square w-full object-cover"
              />
            ) : (
              <div className="aspect-square bg-muted" />
            )}
          </div>
          {images.length > 1 ? (
            <div className="mt-3 grid grid-cols-5 gap-2">
              {images.slice(0, 5).map((img, i) => (
                <button
                  key={`${img.id}-${i}`}
                  type="button"
                  onClick={() => setActive(i)}
                  className={`overflow-hidden rounded-md border ${
                    i === active ? "border-accent" : "border-transparent"
                  }`}
                >
                  <img src={img.thumbnail || img.src} alt="" className="aspect-square object-cover" />
                </button>
              ))}
            </div>
          ) : null}
        </div>

        <div>
          <div className="flex flex-wrap gap-2">
            {off ? <Badge variant="sale">-{off}%</Badge> : null}
            {product.is_in_stock ? (
              <Badge variant="outline">Tersedia</Badge>
            ) : (
              <Badge variant="outline">Habis</Badge>
            )}
          </div>
          <h1 className="mt-4 font-display text-3xl leading-tight sm:text-4xl">
            {decodeHtml(product.name)}
          </h1>
          <div className="mt-4 flex items-baseline gap-3">
            <span className="text-2xl font-medium tabular-nums">{priced.label}</span>
            {priced.onSale ? (
              <span className="text-sm tabular-nums text-muted-foreground line-through">
                {priced.regularLabel}
              </span>
            ) : null}
          </div>
          {stripHtml(product.short_description) ? (
            <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
              {stripHtml(product.short_description)}
            </p>
          ) : null}

          <div className="mt-8 flex flex-wrap items-center gap-3">
            <QtyStepper value={qty} onChange={setQty} max={product.add_to_cart?.maximum ?? 99} />
            <Button
              size="lg"
              disabled={!product.is_purchasable || !product.is_in_stock}
              onClick={() => add(product, qty)}
            >
              Tambah ke keranjang
            </Button>
          </div>
          <Button asChild variant="outline" className="mt-3" size="lg">
            <a href={product.permalink || OFFICIAL_STORE} target="_blank" rel="noreferrer">
              Lihat di citiuscam.com
            </a>
          </Button>

          {product.attributes?.length ? (
            <dl className="mt-8 grid grid-cols-2 gap-3 text-sm">
              {product.attributes.map((attr) => (
                <div key={attr.id} className="rounded-lg border border-border bg-surface px-3 py-3">
                  <dt className="text-[10px] uppercase tracking-[0.14em] text-muted-foreground">
                    {attr.name}
                  </dt>
                  <dd className="mt-1">{attr.terms.map((t) => t.name).join(", ")}</dd>
                </div>
              ))}
            </dl>
          ) : null}

          <div className="mt-8 flex flex-wrap gap-2">
            {product.categories.map((cat) => (
              <Link
                key={cat.id}
                to="/kategori/$slug"
                params={{ slug: cat.slug }}
                className="rounded-full border border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
              >
                {decodeHtml(cat.name)}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {product.description ? (
        <section className="mt-14 max-w-3xl">
          <h2 className="font-display text-2xl">Detail</h2>
          <div
            className="prose-citius mt-4 space-y-3 text-sm leading-relaxed text-muted-foreground [&_li]:ml-5 [&_li]:list-disc [&_p]:text-pretty"
            dangerouslySetInnerHTML={{ __html: sanitizeHtml(product.description) }}
          />
        </section>
      ) : null}

      {related.length ? (
        <section className="mt-16">
          <h2 className="mb-8 font-display text-3xl">Produk terkait</h2>
          <ProductGrid products={related} />
        </section>
      ) : null}
    </div>
  );
}
