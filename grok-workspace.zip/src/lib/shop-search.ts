export type ShopSearch = {
  q?: string;
  page?: number;
  orderby?: "date" | "price" | "popularity" | "title";
  order?: "asc" | "desc";
  on_sale?: boolean;
};

export function parseShopSearch(search: Record<string, unknown>): ShopSearch {
  const orderbyRaw = search.orderby;
  const orderRaw = search.order;
  const orderby =
    orderbyRaw === "date" ||
    orderbyRaw === "price" ||
    orderbyRaw === "popularity" ||
    orderbyRaw === "title"
      ? orderbyRaw
      : undefined;
  const order = orderRaw === "asc" || orderRaw === "desc" ? orderRaw : undefined;
  const pageNum = Number(search.page);
  return {
    q: typeof search.q === "string" && search.q.trim() ? search.q.trim() : undefined,
    page: Number.isFinite(pageNum) && pageNum > 1 ? Math.floor(pageNum) : undefined,
    orderby,
    order,
    on_sale: search.on_sale === true || search.on_sale === "true" ? true : undefined,
  };
}
