import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { WcProduct } from "./wc/types";
import { formatWcPrice, productImage } from "./wc/format";

export type CartItem = {
  id: number;
  slug: string;
  name: string;
  price: number;
  regularPrice: number;
  image: string | null;
  permalink: string;
  qty: number;
  inStock: boolean;
};

type CartState = {
  items: CartItem[];
  add: (product: WcProduct, qty?: number) => void;
  setQty: (id: number, qty: number) => void;
  remove: (id: number) => void;
  clear: () => void;
};

export const useCart = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      add: (product, qty = 1) => {
        const priced = formatWcPrice(product.prices);
        const existing = get().items.find((item) => item.id === product.id);
        if (existing) {
          set({
            items: get().items.map((item) =>
              item.id === product.id ? { ...item, qty: item.qty + qty } : item,
            ),
          });
          return;
        }
        set({
          items: [
            ...get().items,
            {
              id: product.id,
              slug: product.slug,
              name: product.name,
              price: priced.current,
              regularPrice: priced.regular,
              image: productImage(product, "thumb"),
              permalink: product.permalink,
              qty,
              inStock: product.is_in_stock,
            },
          ],
        });
      },
      setQty: (id, qty) => {
        if (qty <= 0) {
          set({ items: get().items.filter((item) => item.id !== id) });
          return;
        }
        set({
          items: get().items.map((item) => (item.id === id ? { ...item, qty } : item)),
        });
      },
      remove: (id) => set({ items: get().items.filter((item) => item.id !== id) }),
      clear: () => set({ items: [] }),
    }),
    { name: "citiuscam-cart" },
  ),
);

export function cartCount(items: CartItem[]): number {
  return items.reduce((sum, item) => sum + item.qty, 0);
}

export function cartSubtotal(items: CartItem[]): number {
  return items.reduce((sum, item) => sum + item.price * item.qty, 0);
}
