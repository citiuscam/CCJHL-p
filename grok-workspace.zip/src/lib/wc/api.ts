import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import type { ProductListResult, StorefrontCatalog, WcProduct, WcTerm } from "./types";

const WC_STORE = "https://citiuscam.com/wp-json/wc/store/v1";
const TTL_MS = 45_000;

type Cached<T> = { exp: number; value: T };
const memory = new Map<string, Cached<unknown>>();

function readCache<T>(key: string): T | null {
  const hit = memory.get(key);
  if (!hit) return null;
  if (hit.exp < Date.now()) {
    memory.delete(key);
    return null;
  }
  return hit.value as T;
}

function writeCache<T>(key: string, value: T): T {
  memory.set(key, { exp: Date.now() + TTL_MS, value });
  return value;
}

type WcFetchResult<T> = { data: T; total: number; totalPages: number };

async function wcGet<T>(path: string): Promise<WcFetchResult<T>> {
  const key = path;
  const cached = readCache<WcFetchResult<T>>(key);
  if (cached) return cached;

  const url = `${WC_STORE}${path}`;
  const res = await fetch(url, {
    headers: { Accept: "application/json" },
  });
  if (!res.ok) {
    throw new Error(`Gagal memuat katalog CitiusCam (${res.status})`);
  }
  const data = (await res.json()) as T;
  const packed: WcFetchResult<T> = {
    data,
    total: Number(res.headers.get("X-WP-Total") ?? 0),
    totalPages: Number(res.headers.get("X-WP-TotalPages") ?? 0),
  };
  return writeCache(key, packed);
}

function toQuery(params: Record<string, string | number | boolean | undefined>): string {
  const q = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v === undefined || v === "" || v === false) continue;
    q.set(k, String(v));
  }
  const s = q.toString();
  return s ? `?${s}` : "";
}

const listInput = z.object({
  page: z.number().int().min(1).optional(),
  perPage: z.number().int().min(1).max(48).optional(),
  category: z.union([z.number(), z.string()]).optional(),
  search: z.string().max(80).optional(),
  orderby: z.enum(["date", "price", "popularity", "rating", "title", "menu_order"]).optional(),
  order: z.enum(["asc", "desc"]).optional(),
  onSale: z.boolean().optional(),
  stockStatus: z.enum(["instock", "outofstock", "onbackorder"]).optional(),
});

export const listProducts = createServerFn({ method: "GET" })
  .validator(listInput)
  .handler(async ({ data }): Promise<ProductListResult> => {
    const path = `/products${toQuery({
      page: data.page ?? 1,
      per_page: data.perPage ?? 12,
      category: data.category,
      search: data.search,
      orderby: data.orderby ?? "date",
      order: data.order ?? "desc",
      on_sale: data.onSale ? true : undefined,
      stock_status: data.stockStatus,
    })}`;
    const result = await wcGet<WcProduct[]>(path);
    return {
      products: result.data,
      total: result.total,
      totalPages: result.totalPages,
    };
  });

export const getProductBySlug = createServerFn({ method: "GET" })
  .validator(z.object({ slug: z.string().min(1).max(200) }))
  .handler(async ({ data }): Promise<WcProduct | null> => {
    const listed = await wcGet<WcProduct[]>(
      `/products${toQuery({ slug: data.slug, per_page: 1 })}`,
    );
    const match = listed.data.find((p) => p.slug === data.slug);
    if (match) {
      const full = await wcGet<WcProduct>(`/products/${match.id}`);
      return full.data;
    }
    try {
      const bySlug = await wcGet<WcProduct>(`/products/${encodeURIComponent(data.slug)}`);
      return bySlug.data;
    } catch {
      return null;
    }
  });

export const getProductById = createServerFn({ method: "GET" })
  .validator(z.object({ id: z.number().int().positive() }))
  .handler(async ({ data }): Promise<WcProduct | null> => {
    try {
      const result = await wcGet<WcProduct>(`/products/${data.id}`);
      return result.data;
    } catch {
      return null;
    }
  });

export const listCategories = createServerFn({ method: "GET" }).handler(
  async (): Promise<WcTerm[]> => {
    const result = await wcGet<WcTerm[]>("/products/categories?per_page=100");
    return result.data.filter((c) => (c.count ?? 0) > 0);
  },
);

export const getCatalogHome = createServerFn({ method: "GET" }).handler(
  async (): Promise<StorefrontCatalog> => {
    const [latest, clearance, adapters, accessories, cameras, lenses, preloved, best, categories] =
      await Promise.all([
        wcGet<WcProduct[]>("/products?per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=343&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=81&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=29&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=40&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=64&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=151&per_page=8&orderby=date&order=desc"),
        wcGet<WcProduct[]>("/products?category=345&per_page=8&orderby=date&order=desc"),
        wcGet<WcTerm[]>("/products/categories?per_page=100"),
      ]);

    const allLatest = await wcGet<WcProduct[]>("/products?per_page=1");

    return {
      latest: latest.data,
      clearance: clearance.data,
      adapters: adapters.data,
      accessories: accessories.data,
      cameras: cameras.data,
      lenses: lenses.data,
      preloved: preloved.data.length ? preloved.data : latest.data.filter((p) =>
        p.categories.some((c) => c.slug === "collectors-preloved" || c.slug === "hobby-gadget"),
      ),
      best: best.data,
      categories: categories.data.filter((c) => (c.count ?? 0) > 0),
      total: allLatest.total,
    };
  },
);

export const searchProducts = createServerFn({ method: "GET" })
  .validator(z.object({ q: z.string().min(1).max(80) }))
  .handler(async ({ data }): Promise<WcProduct[]> => {
    const result = await wcGet<WcProduct[]>(
      `/products${toQuery({ search: data.q, per_page: 8, orderby: "popularity" })}`,
    );
    return result.data;
  });
