import type { WcPrice, WcProduct } from "./types";

export const WC_ORIGIN = "https://citiuscam.com";
export const COUPON_CODE = "10-OFF26";
export const STORE_NAME = "CitiusCam";
export const STORE_TAGLINE = "Shoot with Style";
export const TELEGRAM_URL = "https://t.me/citiuscam";
export const INSTAGRAM_URL = "https://instagram.com/citiuscam";
export const FACEBOOK_URL = "https://fb.me/citiuscam";
export const X_URL = "https://twitter.com/citiuscam";
export const OFFICIAL_STORE = "https://citiuscam.com";

export const NAV_CATEGORIES = [
  { slug: "adapter-lensa", label: "Adapter" },
  { slug: "kamera", label: "Kamera" },
  { slug: "lensa", label: "Lensa" },
  { slug: "aksesoris", label: "Aksesoris" },
  { slug: "cuci-gudang", label: "Cuci Gudang" },
  { slug: "collectors-preloved", label: "Preloved" },
] as const;

export const FEATURED_CATEGORY_SLUGS = [
  "adapter-lensa",
  "kamera",
  "lensa",
  "aksesoris",
  "cuci-gudang",
  "collectors-preloved",
  "best-seller",
  "promo",
  "flash-speedlight-blitz-led",
] as const;

export function decodeHtml(value: string): string {
  return value
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/&#x([0-9a-f]+);/gi, (_, hex: string) =>
      String.fromCharCode(Number.parseInt(hex, 16)),
    )
    .replace(/&/g, "&")
    .replace(/"/g, '"')
    .replace(/'/g, "'")
    .replace(/</g, "<")
    .replace(/>/g, ">")
    .replace(/&nbsp;/g, " ");
}

export function stripHtml(html: string | null | undefined): string {
  if (!html) return "";
  return decodeHtml(html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

export function sanitizeHtml(html: string | null | undefined): string {
  if (!html) return "";
  return html
    .replace(/<script[\s\S]*?>[\s\S]*?<\/script>/gi, "")
    .replace(/<style[\s\S]*?>[\s\S]*?<\/style>/gi, "")
    .replace(/\son\w+="[^"]*"/gi, "")
    .replace(/\son\w+='[^']*'/gi, "")
    .replace(/javascript:/gi, "");
}

export function priceNumber(raw: string, minorUnit: number): number {
  const n = Number(raw);
  if (!Number.isFinite(n)) return 0;
  return n / 10 ** minorUnit;
}

export function formatIdr(amount: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatWcPrice(prices: WcPrice): {
  current: number;
  regular: number;
  onSale: boolean;
  label: string;
  regularLabel: string;
} {
  const current = priceNumber(prices.price, prices.currency_minor_unit);
  const regular = priceNumber(prices.regular_price, prices.currency_minor_unit);
  const onSale = current > 0 && regular > current;
  return {
    current,
    regular,
    onSale,
    label: formatIdr(current),
    regularLabel: formatIdr(regular),
  };
}

export function discountPercent(prices: WcPrice): number | null {
  const { current, regular, onSale } = formatWcPrice(prices);
  if (!onSale || regular <= 0) return null;
  return Math.round(((regular - current) / regular) * 100);
}

export function productImage(product: WcProduct, size: "full" | "thumb" = "full"): string | null {
  const img = product.images[0];
  if (!img) return null;
  return size === "thumb" ? img.thumbnail || img.src : img.src;
}

export function primaryCategory(product: WcProduct): string {
  const preferred = product.categories.find((c) =>
    ["adapter-lensa", "kamera", "lensa", "aksesoris", "cuci-gudang", "collectors-preloved"].includes(
      c.slug,
    ),
  );
  return decodeHtml((preferred ?? product.categories[0])?.name ?? "Gear");
}
