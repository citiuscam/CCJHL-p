export type WcPrice = {
  price: string;
  regular_price: string;
  sale_price: string;
  price_range: { min_amount: string; max_amount: string } | null;
  currency_code: string;
  currency_symbol: string;
  currency_minor_unit: number;
  currency_decimal_separator: string;
  currency_thousand_separator: string;
  currency_prefix: string;
  currency_suffix: string;
};

export type WcImage = {
  id: number;
  src: string;
  thumbnail: string;
  srcset: string | null;
  sizes: string | null;
  name: string;
  alt: string | null;
};

export type WcTerm = {
  id: number;
  name: string;
  slug: string;
  link?: string;
  parent?: number;
  count?: number;
  description?: string;
  image?: WcImage | null;
};

export type WcAttribute = {
  id: number;
  name: string;
  taxonomy: string;
  has_variations: boolean;
  terms: { id: number; name: string; slug: string }[];
};

export type WcProduct = {
  id: number;
  name: string;
  slug: string;
  parent: number;
  type: string;
  permalink: string;
  sku: string | null;
  short_description: string | null;
  description: string | null;
  on_sale: boolean;
  prices: WcPrice;
  average_rating: string;
  review_count: number;
  images: WcImage[];
  categories: WcTerm[];
  tags: WcTerm[];
  attributes: WcAttribute[] | null;
  has_options: boolean;
  is_purchasable: boolean;
  is_in_stock: boolean;
  is_on_backorder: boolean;
  stock_availability: { text: string; class: string };
  add_to_cart: {
    text: string;
    description: string;
    url: string;
    single_text: string;
    minimum: number;
    maximum: number;
    multiple_of: number;
  };
};

export type ProductListResult = {
  products: WcProduct[];
  total: number;
  totalPages: number;
};

export type StorefrontCatalog = {
  latest: WcProduct[];
  clearance: WcProduct[];
  adapters: WcProduct[];
  accessories: WcProduct[];
  cameras: WcProduct[];
  lenses: WcProduct[];
  preloved: WcProduct[];
  best: WcProduct[];
  categories: WcTerm[];
  total: number;
};
