export default defineNuxtConfig({
  compatibilityDate: "2025-10-01",
  css: ["~/assets/css/main.css"],
  app: {
    head: {
      title: "CitiusCam — Shoot with Style",
      htmlAttrs: { lang: "id" },
      meta: [
        {
          name: "description",
          content:
            "Headless Vue/Nuxt storefront for CitiusCam Jakarta. Live WooCommerce Store REST API.",
        },
        { name: "theme-color", content: "#0e0d0c" },
      ],
      link: [
        { rel: "icon", type: "image/svg+xml", href: "/favicon.svg" },
        { rel: "preconnect", href: "https://fonts.googleapis.com" },
        { rel: "preconnect", href: "https://fonts.gstatic.com", crossorigin: "" },
        {
          rel: "stylesheet",
          href: "https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Outfit:wght@400;500;600&display=swap",
        },
      ],
    },
  },
  runtimeConfig: {
    wcBase: "https://citiuscam.com/wp-json/wc/store/v1",
  },
});
