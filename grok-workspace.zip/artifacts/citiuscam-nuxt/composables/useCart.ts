export type CartItem = {
  id: number;
  slug: string;
  name: string;
  price: number;
  image: string | null;
  permalink: string;
  qty: number;
};

const KEY = "citiuscam-cart";

export function useCart() {
  const items = useState<CartItem[]>("cart-items", () => []);

  onMounted(() => {
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) items.value = JSON.parse(raw);
    } catch {
      /* ignore */
    }
  });

  function persist() {
    if (import.meta.client) localStorage.setItem(KEY, JSON.stringify(items.value));
  }

  function add(item: Omit<CartItem, "qty">, qty = 1) {
    const found = items.value.find((i) => i.id === item.id);
    if (found) found.qty += qty;
    else items.value.push({ ...item, qty });
    persist();
  }

  function setQty(id: number, qty: number) {
    if (qty <= 0) items.value = items.value.filter((i) => i.id !== id);
    else {
      const found = items.value.find((i) => i.id === id);
      if (found) found.qty = qty;
    }
    persist();
  }

  function remove(id: number) {
    items.value = items.value.filter((i) => i.id !== id);
    persist();
  }

  function clear() {
    items.value = [];
    persist();
  }

  const count = computed(() => items.value.reduce((n, i) => n + i.qty, 0));
  const subtotal = computed(() => items.value.reduce((n, i) => n + i.price * i.qty, 0));

  return { items, add, setQty, remove, clear, count, subtotal };
}
