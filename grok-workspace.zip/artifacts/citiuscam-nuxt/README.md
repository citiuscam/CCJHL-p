# CitiusCam — Nuxt 3 Headless Storefront

Vue 3 / Nuxt 3 storefront that reads the live WooCommerce **Store REST API** from
[citiuscam.com](https://citiuscam.com).

```
GET https://citiuscam.com/wp-json/wc/store/v1/products
GET https://citiuscam.com/wp-json/wc/store/v1/products/{id}
GET https://citiuscam.com/wp-json/wc/store/v1/products/categories
```

Nitro server routes proxy those endpoints so the browser never hits CORS.

## Run

```bash
npm install
npm run dev
```

Open http://localhost:3000

## Stack

- Nuxt 3 + Vue 3
- Nitro API proxy (`server/api/wc/*`)
- Cart in `localStorage` via `composables/useCart.ts`
- Checkout composes a Telegram order for [@citiuscam](https://t.me/citiuscam)
- Voucher `10-OFF26` (10% at the official store)

## Deploy

```bash
npm run build
```

Works on Node hosts, Vercel, Netlify, and Cloudflare. Set nothing — the store
URL is already pointed at citiuscam.com.

To point at another WooCommerce shop, change `runtimeConfig.wcBase` in
`nuxt.config.ts`.
