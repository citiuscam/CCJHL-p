import { wcFetch } from "../../utils/wc";

export default defineEventHandler(async (event) => {
  const query = getQuery(event);
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(query)) {
    if (value != null && value !== "") params.set(key, String(value));
  }
  const qs = params.toString();
  const result = await wcFetch<unknown[]>(`/products${qs ? `?${qs}` : ""}`);
  return result;
});
