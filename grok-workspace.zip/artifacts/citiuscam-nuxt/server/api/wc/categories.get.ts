import { wcFetch } from "../../utils/wc";

export default defineEventHandler(async () => {
  const result = await wcFetch<Array<{ count?: number }>>("/products/categories?per_page=100");
  return result.data.filter((c) => (c.count ?? 0) > 0);
});
