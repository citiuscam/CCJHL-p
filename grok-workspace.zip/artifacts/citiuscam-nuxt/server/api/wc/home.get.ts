import { wcFetch } from "../../utils/wc";

export default defineEventHandler(async () => {
  const [latest, clearance, adapters, cameras, lenses, accessories] = await Promise.all([
    wcFetch("/products?per_page=8&orderby=date&order=desc"),
    wcFetch("/products?category=343&per_page=8"),
    wcFetch("/products?category=81&per_page=8"),
    wcFetch("/products?category=40&per_page=8"),
    wcFetch("/products?category=64&per_page=8"),
    wcFetch("/products?category=29&per_page=8"),
  ]);
  return {
    latest: latest.data,
    clearance: clearance.data,
    adapters: adapters.data,
    cameras: cameras.data,
    lenses: lenses.data,
    accessories: accessories.data,
    total: latest.total,
  };
});
