import { wcFetch } from "../../utils/wc";

export default defineEventHandler(async (event) => {
  const { slug, id } = getQuery(event);
  if (id) {
    const result = await wcFetch(`/products/${id}`);
    return result.data;
  }
  if (!slug) {
    throw createError({ statusCode: 400, statusMessage: "slug or id required" });
  }
  const listed = await wcFetch<Array<{ id: number; slug: string }>>(
    `/products?slug=${encodeURIComponent(String(slug))}&per_page=1`,
  );
  const match = listed.data[0];
  if (!match) {
    throw createError({ statusCode: 404, statusMessage: "Not found" });
  }
  const full = await wcFetch(`/products/${match.id}`);
  return full.data;
});
