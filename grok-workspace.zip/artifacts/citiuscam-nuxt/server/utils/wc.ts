export async function wcFetch<T>(path: string) {
  const config = useRuntimeConfig();
  const url = `${config.wcBase}${path}`;
  const res = await fetch(url, { headers: { Accept: "application/json" } });
  if (!res.ok) {
    throw createError({ statusCode: res.status, statusMessage: `WooCommerce ${res.status}` });
  }
  const data = (await res.json()) as T;
  return {
    data,
    total: Number(res.headers.get("X-WP-Total") || 0),
    totalPages: Number(res.headers.get("X-WP-TotalPages") || 0),
  };
}
