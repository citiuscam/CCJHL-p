<script setup lang="ts">
const route = useRoute();
const slug = computed(() => String(route.params.slug));

const { data: categories } = await useFetch<any[]>("/api/wc/categories");
const category = computed(() => categories.value?.find((c) => c.slug === slug.value));

const { data } = await useFetch("/api/wc/products", {
  query: computed(() => ({
    category: category.value?.id,
    per_page: 12,
    orderby: "date",
    order: "desc",
  })),
});
</script>

<template>
  <div class="wrap section">
    <p class="kicker">Kategori</p>
    <h1>{{ category?.name || slug }}</h1>
    <p class="muted">{{ data?.total || 0 }} produk</p>
    <div class="grid" style="margin-top: 32px">
      <ProductCard v-for="p in data?.data || []" :key="p.id" :product="p" />
    </div>
  </div>
</template>
