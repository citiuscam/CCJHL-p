<script setup lang="ts">
import { formatIdr } from "~/utils/format";

const { items, subtotal, clear } = useCart();
const name = ref("");
const phone = ref("");
const city = ref("Jakarta");
const note = ref("");

const message = computed(() => {
  const lines = items.value.map((i) => `- ${i.name} × ${i.qty} @ ${formatIdr(i.price)}`);
  return [
    "Pesanan CitiusCam",
    `Nama: ${name.value}`,
    `WA: ${phone.value}`,
    `Kota: ${city.value}`,
    "",
    ...lines,
    "",
    `Subtotal: ${formatIdr(subtotal.value)}`,
    "Voucher: 10-OFF26",
    note.value ? `Catatan: ${note.value}` : "",
  ]
    .filter(Boolean)
    .join("\n");
});

function submit() {
  const url = `https://t.me/citiuscam?text=${encodeURIComponent(message.value)}`;
  window.open(url, "_blank", "noopener,noreferrer");
  clear();
}
</script>

<template>
  <div class="wrap section" style="display:grid; gap:32px; grid-template-columns: 1fr 0.8fr">
    <form @submit.prevent="submit">
      <h1>Checkout</h1>
      <p class="muted">Ringkasan dikirim ke Telegram @citiuscam. Bayar di toko resmi. Voucher 10-OFF26.</p>
      <p><input class="field" v-model="name" required placeholder="Nama" style="width:100%;margin-top:12px" /></p>
      <p><input class="field" v-model="phone" required placeholder="WhatsApp" style="width:100%;margin-top:12px" /></p>
      <p><input class="field" v-model="city" required placeholder="Kota" style="width:100%;margin-top:12px" /></p>
      <p><input class="field" v-model="note" placeholder="Catatan" style="width:100%;margin-top:12px" /></p>
      <button class="btn" style="margin-top:16px" type="submit">Kirim via Telegram</button>
    </form>
    <aside>
      <h2>Ringkasan</h2>
      <p v-for="item in items" :key="item.id" class="muted">
        {{ item.name }} × {{ item.qty }} — {{ formatIdr(item.price * item.qty) }}
      </p>
      <p><strong>{{ formatIdr(subtotal) }}</strong></p>
    </aside>
  </div>
</template>
