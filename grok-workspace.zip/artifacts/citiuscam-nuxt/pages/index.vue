<script setup lang="ts">
import { decodeHtml } from "~/utils/format";

const { data: latestRes } = await useFetch("/api/wc/products", {
  query: { per_page: 8, orderby: "date", order: "desc" },
});
const { data: clearanceRes } = await useFetch("/api/wc/products", {
  query: { category: 343, per_page: 8 },
});

const latest = computed(() => latestRes.value?.data || []);
const clearance = computed(() => clearanceRes.value?.data || []);
const featured = computed(() => latest.value?.[0]);
const total = computed(() => latestRes.value?.total || 0);
</script>

<template>
  <div>
    <section class="hero">
      <div class="hero-copy wrap" style="width: auto; padding-left: max(16px, calc((100% - 1120px) / 2))">
        <p class="kicker">Jakarta · Camera house</p>
        <h1>Shoot with<br /><em>Style</em></h1>
        <p>
          Adapter lensa, aksesoris, vintage manual, dan preloved langka. Katalog live dari WooCommerce
          Store REST API CitiusCam.
        </p>
        <p style="margin-top: 24px; display: flex; gap: 12px">
          <NuxtLink to="/toko" class="btn">Belanja sekarang</NuxtLink>
          <NuxtLink to="/kategori/cuci-gudang" class="btn ghost">Cuci gudang</NuxtLink>
        </p>
        <p class="muted" style="margin-top: 16px">{{ total }} produk · Kode voucher 10-OFF26</p>
      </div>
      <div class="hero-media">
        <img v-if="featured?.images?.[0]" :src="featured.images[0].src" :alt="decodeHtml(featured.name)" />
        <div v-if="featured" class="hero-caption">
          <p class="kicker">Terbaru</p>
          <NuxtLink :to="`/produk/${featured.slug}`">
            <h2>{{ decodeHtml(featured.name) }}</h2>
          </NuxtLink>
        </div>
      </div>
    </section>

    <section class="section wrap">
      <div class="section-head">
        <div>
          <p class="kicker">Baru masuk</p>
          <h2>Produk terbaru</h2>
        </div>
        <NuxtLink to="/toko" class="muted">Semua</NuxtLink>
      </div>
      <div class="grid">
        <ProductCard v-for="p in latest" :key="p.id" :product="p" />
      </div>
    </section>

    <section class="promo">
      <div class="wrap" style="display: flex; justify-content: space-between; align-items: center; gap: 16px; flex-wrap: wrap">
        <div>
          <p class="kicker" style="color: var(--sale)">Penawaran terbatas</p>
          <h2>Diskon 10% dengan 10-OFF26</h2>
        </div>
        <NuxtLink to="/toko?on_sale=true" class="btn">Lihat yang diskon</NuxtLink>
      </div>
    </section>

    <section class="section wrap">
      <div class="section-head">
        <div>
          <p class="kicker">Stok gudang</p>
          <h2>Cuci gudang</h2>
        </div>
        <NuxtLink to="/kategori/cuci-gudang" class="muted">Semua</NuxtLink>
      </div>
      <div class="grid">
        <ProductCard v-for="p in clearance" :key="p.id" :product="p" />
      </div>
    </section>
  </div>
</template>
