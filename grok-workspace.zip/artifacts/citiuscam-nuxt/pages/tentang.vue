<template>
  <article class="wrap section">
    <p class="kicker">CitiusCam Jakarta</p>
    <h1>Shoot with Style</h1>
    <p class="muted" style="max-width: 640px; line-height: 1.7; margin-top: 20px">
      CitiusCam adalah rumah aksesoris kamera dan gadget di Jakarta. Storefront Nuxt ini headless:
      katalog, harga, dan stok ditarik live dari WooCommerce Store REST API
      <code>/wp-json/wc/store/v1</code>.
    </p>
    <p style="margin-top: 20px">
      <a href="https://citiuscam.com">citiuscam.com</a>
      ·
      <a href="https://instagram.com/citiuscam">Instagram</a>
      ·
      <a href="https://t.me/citiuscam">Telegram</a>
    </p>
  </article>
</template>
