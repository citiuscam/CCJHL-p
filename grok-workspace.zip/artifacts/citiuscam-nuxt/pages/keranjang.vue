<script setup lang="ts">
import { formatIdr } from "~/utils/format";
const { items, setQty, remove, subtotal } = useCart();
</script>

<template>
  <div class="wrap section">
    <h1>Keranjang</h1>
    <p v-if="!items.length" class="muted">Belum ada gear.</p>
    <div v-else>
      <div v-for="item in items" :key="item.id" class="cart-row">
        <img v-if="item.image" :src="item.image" alt="" />
        <div>
          <NuxtLink :to="`/produk/${item.slug}`">{{ item.name }}</NuxtLink>
          <p class="muted">{{ formatIdr(item.price) }}</p>
          <button class="muted" style="background:none;border:0;padding:0" @click="remove(item.id)">Hapus</button>
        </div>
        <div>
          <div class="qty">
            <button @click="setQty(item.id, item.qty - 1)">−</button>
            <span style="width: 32px; display: grid; place-items: center">{{ item.qty }}</span>
            <button @click="setQty(item.id, item.qty + 1)">+</button>
          </div>
          <p class="price">{{ formatIdr(item.price * item.qty) }}</p>
        </div>
      </div>
      <p style="margin-top: 24px">Subtotal <strong>{{ formatIdr(subtotal) }}</strong></p>
      <NuxtLink to="/checkout" class="btn" style="margin-top: 16px">Lanjut checkout</NuxtLink>
    </div>
  </div>
</template>
