<script setup lang="ts">
const route = useRoute();
const q = ref(String(route.query.q || ""));
const page = computed(() => Number(route.query.page || 1));
const onSale = computed(() => route.query.on_sale === "true");

const { data } = await useFetch("/api/wc/products", {
  query: computed(() => ({
    page: page.value,
    per_page: 12,
    search: q.value || undefined,
    on_sale: onSale.value || undefined,
    orderby: "date",
    order: "desc",
  })),
});

function apply() {
  navigateTo({ path: "/toko", query: { q: q.value || undefined, on_sale: onSale.value ? "true" : undefined } });
}
</script>

<template>
  <div class="wrap section">
    <p class="kicker">Etalase</p>
    <h1>Semua produk</h1>
    <p class="muted">{{ data?.total || 0 }} item dari WooCommerce Store API</p>
    <form class="search" style="margin: 24px 0" @submit.prevent="apply">
      <input v-model="q" placeholder="Cari sony, adapter, leica…" />
      <button class="btn" type="submit">Cari</button>
    </form>
    <div class="grid">
      <ProductCard v-for="p in data?.data || []" :key="p.id" :product="p" />
    </div>
  </div>
</template>
