<script setup lang="ts">
import { decodeHtml, formatIdr, stripHtml, wcAmount } from "~/utils/format";

const route = useRoute();
const { data: product } = await useFetch<any>("/api/wc/product", {
  query: { slug: route.params.slug },
});
const { add } = useCart();
const qty = ref(1);
const active = ref(0);

const price = computed(() =>
  product.value ? wcAmount(product.value.prices.price, product.value.prices.currency_minor_unit) : 0,
);
const img = computed(() => product.value?.images?.[active.value] || product.value?.images?.[0]);

function addItem() {
  if (!product.value) return;
  add(
    {
      id: product.value.id,
      slug: product.value.slug,
      name: decodeHtml(product.value.name),
      price: price.value,
      image: product.value.images?.[0]?.thumbnail || null,
      permalink: product.value.permalink,
    },
    qty.value,
  );
}
</script>

<template>
  <div v-if="product" class="wrap">
    <div class="pdp">
      <div>
        <img v-if="img" class="main" :src="img.src" :alt="decodeHtml(product.name)" />
        <div v-if="product.images?.length > 1" class="thumbs">
          <button
            v-for="(im, i) in product.images.slice(0, 5)"
            :key="im.id"
            :class="{ active: i === active }"
            @click="active = i"
          >
            <img :src="im.thumbnail || im.src" alt="" />
          </button>
        </div>
      </div>
      <div>
        <p class="kicker">{{ product.categories?.[0]?.name }}</p>
        <h1>{{ decodeHtml(product.name) }}</h1>
        <p class="price" style="font-size: 24px; margin: 16px 0">{{ formatIdr(price) }}</p>
        <p class="muted">{{ stripHtml(product.short_description) }}</p>
        <div style="display: flex; gap: 12px; margin-top: 24px">
          <div class="qty">
            <button type="button" @click="qty = Math.max(1, qty - 1)">−</button>
            <span style="width: 32px; display: grid; place-items: center">{{ qty }}</span>
            <button type="button" @click="qty += 1">+</button>
          </div>
          <button class="btn" @click="addItem">Tambah ke keranjang</button>
        </div>
        <p style="margin-top: 16px">
          <a class="muted" :href="product.permalink" target="_blank">Lihat di citiuscam.com</a>
        </p>
      </div>
    </div>
    <section class="section" v-if="product.description">
      <h2>Detail</h2>
      <div class="muted" style="margin-top: 16px; line-height: 1.6" v-html="product.description" />
    </section>
  </div>
</template>
