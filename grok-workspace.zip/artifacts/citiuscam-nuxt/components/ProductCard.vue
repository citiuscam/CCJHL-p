<script setup lang="ts">
import { decodeHtml, formatIdr, wcAmount } from "~/utils/format";

const props = defineProps<{ product: any }>();
const { add } = useCart();

const price = computed(() => wcAmount(props.product.prices.price, props.product.prices.currency_minor_unit));
const regular = computed(() =>
  wcAmount(props.product.prices.regular_price, props.product.prices.currency_minor_unit),
);
const onSale = computed(() => price.value > 0 && regular.value > price.value);
const img = computed(() => props.product.images?.[0]?.src);

function addItem() {
  add({
    id: props.product.id,
    slug: props.product.slug,
    name: decodeHtml(props.product.name),
    price: price.value,
    image: props.product.images?.[0]?.thumbnail || img.value || null,
    permalink: props.product.permalink,
  });
}
</script>

<template>
  <article class="card">
    <NuxtLink :to="`/produk/${product.slug}`">
      <div class="card-img">
        <img v-if="img" :src="img" :alt="decodeHtml(product.name)" />
        <span v-if="onSale" class="sale">Sale</span>
      </div>
      <h3>{{ decodeHtml(product.name) }}</h3>
    </NuxtLink>
    <p class="price">
      {{ formatIdr(price) }}
      <s v-if="onSale">{{ formatIdr(regular) }}</s>
    </p>
    <button class="btn ghost" style="height: 36px; margin-top: 8px; width: 100%" @click="addItem">
      Tambah
    </button>
  </article>
</template>
