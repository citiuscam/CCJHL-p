<script setup lang="ts">
const q = ref("");
const { count } = useCart();
const router = useRouter();

function search() {
  router.push({ path: "/toko", query: { q: q.value || undefined } });
}
</script>

<template>
  <header class="header">
    <div class="topbar">Jakarta · Voucher 10-OFF26 · Diskon 10%</div>
    <div class="wrap header-row">
      <NuxtLink to="/" class="brand">
        <svg width="28" height="28" viewBox="0 0 32 32" fill="none" stroke="currentColor">
          <circle cx="16" cy="16" r="13" stroke-width="1.5" />
          <circle cx="16" cy="16" r="5" stroke-width="1.25" />
        </svg>
        CitiusCam
      </NuxtLink>
      <nav class="nav">
        <NuxtLink to="/toko">Toko</NuxtLink>
        <NuxtLink to="/kategori/adapter-lensa">Adapter</NuxtLink>
        <NuxtLink to="/kategori/kamera">Kamera</NuxtLink>
        <NuxtLink to="/kategori/lensa">Lensa</NuxtLink>
        <NuxtLink to="/kategori/aksesoris">Aksesoris</NuxtLink>
        <NuxtLink to="/kategori/cuci-gudang">Cuci Gudang</NuxtLink>
      </nav>
      <form class="search" @submit.prevent="search">
        <input v-model="q" placeholder="Cari adapter, sony, leica…" />
        <NuxtLink to="/keranjang" class="icon-btn" aria-label="Keranjang">
          bag
          <span v-if="count" class="badge-count">{{ count }}</span>
        </NuxtLink>
      </form>
    </div>
  </header>
</template>
