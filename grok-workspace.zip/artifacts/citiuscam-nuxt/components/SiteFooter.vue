<template>
  <footer class="footer">
    <div class="wrap footer-grid">
      <div>
        <h2>CitiusCam</h2>
        <p class="muted" style="margin-top: 8px; max-width: 280px; line-height: 1.5">
          Camera accessories & gadgets dari Jakarta. Headless Nuxt storefront on the WooCommerce Store API.
        </p>
      </div>
      <div>
        <p class="kicker">Etalase</p>
        <p><NuxtLink to="/kategori/adapter-lensa">Adapter</NuxtLink></p>
        <p><NuxtLink to="/kategori/kamera">Kamera</NuxtLink></p>
        <p><NuxtLink to="/kategori/lensa">Lensa</NuxtLink></p>
        <p><NuxtLink to="/kategori/cuci-gudang">Cuci Gudang</NuxtLink></p>
      </div>
      <div>
        <p class="kicker">Toko</p>
        <p><NuxtLink to="/toko">Semua produk</NuxtLink></p>
        <p><NuxtLink to="/tentang">Tentang</NuxtLink></p>
        <p><a href="https://citiuscam.com" target="_blank" rel="noreferrer">citiuscam.com</a></p>
      </div>
      <div>
        <p class="kicker">Kanal</p>
        <p><a href="https://instagram.com/citiuscam" target="_blank">Instagram</a></p>
        <p><a href="https://t.me/citiuscam" target="_blank">Telegram</a></p>
        <p><a href="https://fb.me/citiuscam" target="_blank">Facebook</a></p>
      </div>
    </div>
  </footer>
</template>
