export function decodeHtml(value: string): string {
  return value
    .replace(/&#(\d+);/g, (_, code: string) => String.fromCharCode(Number(code)))
    .replace(/&/g, "&")
    .replace(/"/g, '"')
    .replace(/&#8217;/g, "'");
}

export function stripHtml(html?: string | null): string {
  if (!html) return "";
  return decodeHtml(html.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim());
}

export function formatIdr(amount: number): string {
  return new Intl.NumberFormat("id-ID", {
    style: "currency",
    currency: "IDR",
    maximumFractionDigits: 0,
  }).format(amount);
}

export function wcAmount(raw: string, minor = 0): number {
  return Number(raw) / 10 ** minor;
}
